import json
import numpy as np
from enum import Enum
from us_benefits_calculator import get_full_path
from us_benefits_calculator.taxes.applicant import Applicant, FilingStatus
from us_benefits_calculator.taxes.form_dependent import Dependent, Form
from us_benefits_calculator.taxes.state import State
from us_benefits_calculator.utils import STATE_ID_TO_ABBREVIATION

import logging

logger = logging.getLogger(__name__)

"""State-Level

Child and Dependent Care Tax Credit (cdctc)
Contains the states that offer their own version of the cdctc to compliment the federal credit.

Assumptions:
    - Applicant did not receive dependent care credit e.g.(employer benefits)
    - All filers who qualify for the federal CDCTC are eligible for the state credit 
    - Married filing single are not eligible to claim credit
    - Spouse is not disabled or student and has earned income
    - Full year resident
"""

class Fields(Enum):
    EARNED_INCOME = "Earned Income"
    SPOUSE_EARNED_INCOME = "Spouse Earned Income"
    FEDERAL_ADJUSTED_GROSS_INCOME = "Federal Adjusted Gross Income"
    FEDERAL_CDCTC = "Federal CDCTC"
    FEDERAL_CDCTC_BEFORE_TAX_LIABILITY = "Federal CDCTC Before Tax Liability"
    INCOME_LIMIT = "Income Limit"
    QUALIFIED_DEPENDENT = "Qualified Dependent"
    REFUNDABLE = "Refundable"
    REFUNDABLE_AMT = "Refundable Amount"
    SMALLEST_OF_VALUES = "Smallest of Values"
    STATE_DECIMAL_AMT = "State Decimal Amount"
    STATE_CREDIT_AMT = "State Credit Amount"
    QUALIFIED_MAX_EXPENSE = "Qualified Max Expense"
    QUALIFIED_MAX_CREDIT = "Qualified Max Credit"


class StateCdctcCalculator:

    def __init__(self, parameters=None):
        if parameters is None:
            # list of all the calculators for each state
            with open(get_full_path('state_cdctc.json')) as parameters_file:
                self.parameters = json.load(parameters_file)
        else:
            self.parameters = parameters

    #=================
    # HELPER FUNCTIONS
    #=================
    def filter_qualified_dependents(self, dependents, qualifying_child_maximum_age):
        qualified_dependents = []
        for d in dependents:
            if d.age() <= qualifying_child_maximum_age:
                qualified_dependents.append(d)
        # must have atleast one qualified dependent to declare cdctc
        return qualified_dependents

    def maximum_qualified_expense(self, number_of_dependents, expenses_by_number):
        if number_of_dependents == 0:
            return 0
       # min value will be the key to lookup in expenses_by_number dict
        return expenses_by_number[str(min(number_of_dependents, len(expenses_by_number.keys())))]

    def maximum_qualified_credit(self, dependent, calculator, form):
        qualified_dependent_list = form.lines.get(Fields.QUALIFIED_DEPENDENT.value)
        # if list of qualified dependents is None, verify and set the applicant's dependents who qualify
        # there are cases where applicant's dependents are not verified till they reach this method
        if qualified_dependent_list is None:
            qualified_dependent_list = self.filter_qualified_dependents(dependent, calculator.get("qualifying_child_maximum_age"))
            form.line(Fields.QUALIFIED_DEPENDENT.value, qualified_dependent_list)
        credit_by_number = calculator.get("qualified_maximum_credit")
        # once verified, get the length of the list and length of the calculator keys
        number_of_dependents = len(qualified_dependent_list)
        number_of_keys = len(credit_by_number.keys())
        # min value will be the key to lookup in credit_by_number dict
        return credit_by_number[str(min(number_of_dependents, number_of_keys))]

    def state_lookup_decimal_amount(self, applicant, calculator, form=None):
        value_dict = {
            "federal_adjusted_gross_income": applicant.federal_adjusted_gross_income,
            "net_income": applicant.net_income,
            "state_adjusted_gross_income": applicant.state_adjusted_gross_income,
            "household_net_income": applicant.household_net_income
        }
        key = "lookup_type"
        lookup_type_value = None
        # for states who don't have a lookup_type and just one credit rate
        if key not in calculator:
            return calculator["multiplier_lookup"][0]["decimal"] # credit rate
        # assign lookup_type_value if lookup_type is in our value dict
        elif value_dict[calculator.get(key)]:
            lookup_type_value = value_dict[calculator["lookup_type"]]
        else:
            raise TypeError(f"{calculator[key]} cannot be None. No support for {calculator[key]} or {calculator[key]} is set to None for Applicant")
        # iterate multiplier_lookup bracket based on value
        for i in calculator["multiplier_lookup"]:
            if "limit" not in i or lookup_type_value <= i["limit"]:
                # Oregon is currently the only state whose instance is a list of age and state decimal
                if isinstance(i["decimal"], list):
                    qualifying_child_maximum_age = calculator.get("qualifying_child_maximum_age")
                    return self.state_lookup_decimal_by_dependent_age(applicant, i["decimal"], form, qualifying_child_maximum_age)
                else:
                    return i["decimal"]
            else:
                continue

    def state_lookup_decimal_by_dependent_age(self, applicant, age_and_decimal_list, form, qualifying_child_maximum_age):
        youngest_dependent_age = None
        qualified_dependent_list = form.lines.get(Fields.QUALIFIED_DEPENDENT.value)
        # filter for qualified dependents
        if qualified_dependent_list is None:
            # if there are no qualified dependents, filter_qualified_dependents() will raise an exception
            qualified_dependent_list = self.filter_qualified_dependents(applicant.dependent, qualifying_child_maximum_age)
            form.line(Fields.QUALIFIED_DEPENDENT.value, qualified_dependent_list)

        if len(qualified_dependent_list) == 0:
            return 0
        # youngest age is set to the first dependent
        youngest_dependent_age = qualified_dependent_list[0].age()
        if len(qualified_dependent_list) > 1:
            # if there are more dependents, search for the youngest dependent
            for dependent in range(1, len(qualified_dependent_list)):
                youngest_dependent_age = min(youngest_dependent_age, qualified_dependent_list[dependent].age())
        # decimal lookup based on the age
        # e.g. age_and_decimal_list = [{"age_limit": 3, "decimal": 0.10}, {"age_limit": 6, "decimal": 0.08}, {"age_limit": 13, "decimal": 0.05}]
        for age_and_decimal in age_and_decimal_list:
            if youngest_dependent_age <= age_and_decimal["age_limit"]:
                return age_and_decimal["decimal"]


    def state_credit_refund(self, calculator, form, value):
        form.line(Fields.REFUNDABLE.value, calculator["refundable"])
        # refundable, to be or not to be
        if calculator["refundable"]:
            form.line(Fields.REFUNDABLE_AMT.value, value * form.lines.get(Fields.STATE_DECIMAL_AMT.value))
            form.line(Fields.STATE_CREDIT_AMT.value, 0)
        else:
            form.line(Fields.STATE_CREDIT_AMT.value, value * form.lines.get(Fields.STATE_DECIMAL_AMT.value))
            form.line(Fields.REFUNDABLE_AMT.value, 0)

    #=====================
    # CALCULATOR FUNCTIONS
    #=====================
    def multiply_state_decimal_by_federal_cdctc(self, applicant, calculator):
        form = Form()
        form.line(Fields.FEDERAL_CDCTC.value, applicant.federal_cdctc) # line 11 of FORM 2441
        form.line(Fields.STATE_DECIMAL_AMT.value, self.state_lookup_decimal_amount(applicant, calculator))
        # Calculates State Credit
        self.state_credit_refund(calculator, form, form.lines.get(Fields.FEDERAL_CDCTC.value))
        return form.lines.get(Fields.STATE_CREDIT_AMT.value), form.lines.get(Fields.REFUNDABLE_AMT.value), form

    def multiply_state_decimal_by_federal_cdctc_before_tax(self, applicant, calculator):
        form = Form()
        form.line(Fields.FEDERAL_CDCTC_BEFORE_TAX_LIABILITY.value, applicant.federal_cdctc_before_tax_liability) # line 9 of FORM 2441
        form.line(Fields.STATE_DECIMAL_AMT.value, self.state_lookup_decimal_amount(applicant, calculator))
        # Calculates State Credit
        self.state_credit_refund(calculator, form, form.lines.get(Fields.FEDERAL_CDCTC_BEFORE_TAX_LIABILITY.value))
        return form.lines.get(Fields.STATE_CREDIT_AMT.value), form.lines.get(Fields.REFUNDABLE_AMT.value), form

    def multiply_state_decimal_by_qualifying_max_expense(self, applicant, calculator):
        form = Form()
        # filters qualifying dependents
        qualifying_child_maximum_age = calculator.get("qualifying_child_maximum_age")
        qualified_dependents = self.filter_qualified_dependents(applicant.dependent, qualifying_child_maximum_age)
        form.line(Fields.QUALIFIED_DEPENDENT.value, qualified_dependents)
        # determines Max Qualifying Expenses
        expenses_by_number = calculator.get("qualified_maximum_expenses")
        form.line(Fields.QUALIFIED_MAX_EXPENSE.value, min(sum(d.cost_of_care() for d in qualified_dependents),
                                                self.maximum_qualified_expense(len(qualified_dependents), expenses_by_number)))
        # calculates state cdctc by qualifying max expense * state decimal
        form.line(Fields.STATE_DECIMAL_AMT.value, self.state_lookup_decimal_amount(applicant, calculator))
        self.state_credit_refund(calculator, form, form.lines.get(Fields.QUALIFIED_MAX_EXPENSE.value))
        return form.lines.get(Fields.STATE_CREDIT_AMT.value), form.lines.get(Fields.REFUNDABLE_AMT.value), form

    def multiply_state_decimal_by_smallest_of_values(self, applicant, calculator):
        form = Form()
        # filters qualifying dependents
        qualifying_child_maximum_age = calculator.get("qualifying_child_maximum_age")
        qualified_dependents = self.filter_qualified_dependents(applicant.dependent, qualifying_child_maximum_age)
        form.line(Fields.QUALIFIED_DEPENDENT.value, qualified_dependents)
        # determines Max Qualifying Expenses
        expenses_by_number = calculator.get("qualified_maximum_expenses")
        form.line(Fields.QUALIFIED_MAX_EXPENSE.value, min(sum(d.cost_of_care() for d in qualified_dependents),
                                                self.maximum_qualified_expense(len(qualified_dependents), expenses_by_number)))
        # input values
        form.line(Fields.EARNED_INCOME.value, applicant.earned_income)
        # applicant's who filing status is Single or HH, don't need to provide spouse earned income
        # therefore applicant's spouse earned income will be the applicant's earned income
        if applicant.filing_status.value != "MFJ":
            form.line(Fields.SPOUSE_EARNED_INCOME.value, applicant.earned_income)
        else:
            if applicant.spouse_earned_income is None:
                raise Exception(f"Applicant's spouse earned income is required")
            form.line(Fields.SPOUSE_EARNED_INCOME.value, applicant.spouse_earned_income)
        # get the smallest of the input values and qualified max expense
        form.line(Fields.SMALLEST_OF_VALUES.value, form.smallest_of_lines(
            form.lines, Fields.QUALIFIED_MAX_EXPENSE.value, Fields.EARNED_INCOME.value, Fields.SPOUSE_EARNED_INCOME.value))
        # calculates the state cdctc by smallest of values * state decimal
        form.line(Fields.STATE_DECIMAL_AMT.value, self.state_lookup_decimal_amount(applicant, calculator, form))
        self.state_credit_refund(calculator, form, form.lines.get(Fields.SMALLEST_OF_VALUES.value))
        return form.lines.get(Fields.STATE_CREDIT_AMT.value), form.lines.get(Fields.REFUNDABLE_AMT.value), form

    # Method is specifically used for the state of Minnesota, fed agi > income limit
    def subtract_income_limit_from_fed_agi_and_multipy_state_decimal(self, applicant, calculator):
        form = Form()
        form.line(Fields.FEDERAL_ADJUSTED_GROSS_INCOME.value, applicant.federal_adjusted_gross_income)
        form.line(Fields.INCOME_LIMIT.value, calculator.get("income_limit")) # arbitrary value from MN state
        result = applicant.federal_adjusted_gross_income - calculator.get("income_limit")
        form.line(Fields.STATE_DECIMAL_AMT.value, self.state_lookup_decimal_amount(applicant, calculator))
        self.state_credit_refund(calculator, form, result)
        form.line(Fields.QUALIFIED_MAX_CREDIT.value, self.maximum_qualified_credit(applicant.dependent, calculator, form))
        if calculator.get("refundable"):
            refund = form.lines.get(Fields.QUALIFIED_MAX_CREDIT.value) - form.lines.get(Fields.REFUNDABLE_AMT.value)
            form.lines[Fields.REFUNDABLE_AMT.value] = refund if refund >=0 else 0
        else:
            credit = form.lines.get(Fields.QUALIFIED_MAX_CREDIT.value) - form.lines.get(Fields.STATE_CREDIT_AMT.value)
            form.lines[Fields.STATE_CREDIT_AMT.value] = credit if credit >=0 else 0
        return form.lines.get(Fields.STATE_CREDIT_AMT.value), form.lines.get(Fields.REFUNDABLE_AMT.value), form

    #===================
    # CALCULATE FUNCTION
    #===================
    def calculate(self, applicant, state_abrv):
        total_state_cdctc = 0
        total_refundable_amt = 0
        if type(state_abrv) == str:
            state = State(self.parameters[state_abrv]) # assign state the list of calcs that belong to the state_abrv
        else:
            state = state_abrv # state_abrv is a list of calcs
        # select calculator(s) that applicant is eligible to use
        matching_calculators = state.select_calculators(applicant)
        forms = []
        # looks for the method_type to start the calculations
        for calculator in matching_calculators:
            if calculator.get("method_type") == "multiply_state_decimal_by_federal_cdctc":
                state_credit, refund, form = self.multiply_state_decimal_by_federal_cdctc(applicant, calculator)
            elif calculator.get("method_type") == "multiply_state_decimal_by_federal_cdctc_before_tax":
                state_credit, refund, form = self.multiply_state_decimal_by_federal_cdctc_before_tax(applicant, calculator)
            elif calculator.get("method_type") == "multiply_state_decimal_by_qualifying_max_expense":
                state_credit, refund, form = self.multiply_state_decimal_by_qualifying_max_expense(applicant, calculator)
            elif calculator.get("method_type") == "multiply_state_decimal_by_smallest_of_values":
                state_credit, refund, form = self.multiply_state_decimal_by_smallest_of_values(applicant, calculator)
            elif calculator.get("method_type") == "subtract_income_limit_from_fed_agi_and_multipy_state_decimal":
                state_credit, refund, form = self.subtract_income_limit_from_fed_agi_and_multipy_state_decimal(applicant, calculator)
            else:
                raise Exception(f"Unknown method_type: ${calculator.get('method_type')}")
            # for states who have a Max Credit and have yet to calculate
            if "qualified_maximum_credit" in calculator and form.lines.get(Fields.QUALIFIED_MAX_CREDIT.value) is None:
                max_credit = self.maximum_qualified_credit(applicant.dependent, calculator, form)
                form.line(Fields.QUALIFIED_MAX_CREDIT.value, max_credit)
                # determine the lesser of credits
                if calculator.get("refundable") and max_credit is not None:
                    refund = min(max_credit, refund)
                elif max_credit is not None:
                    state_credit = min(max_credit, state_credit)
            # total of state credit and/or refund amount
            total_state_cdctc = total_state_cdctc + state_credit
            total_refundable_amt = total_refundable_amt + refund
            forms.append(form)
        # TODO: CONSIDER ADDING LOGIC FOR ARKANSAS REFUNDABLE PROGRAM...LOOK FOR OTHER STATES
        # TODO: CHECK FOR PARTIAL REFUNDABILITY (E.G. MAINE)
        return total_state_cdctc, total_refundable_amt, forms


STATE_CALCULATOR = None

def initialize_calculate_store(args):
    try:
        global STATE_CALCULATOR

        if STATE_CALCULATOR is None:
            STATE_CALCULATOR = StateCdctcCalculator()

        if 'state_id' in args:
            args['state'] = STATE_ID_TO_ABBREVIATION[args['state_id']]

        filing_status = args['filing_status']
        if filing_status == 1:
            filing_status = FilingStatus.SINGLE
        elif filing_status == 2:
            filing_status = FilingStatus.MARRIED_FILING_JOINTLY
        elif filing_status == 3:
            filing_status = FilingStatus.HEAD_OF_HOUSEHOLD
        elif filing_status == 4:
            filing_status = FilingStatus.WIDOW_AND_DEPENDENT
        else:
            raise Exception(f"Unknown filing status {filing_status}")

        dependents = []

        for age in args['child_ages']:
            dependents.append(Dependent(age, args['childcare_expenses'] / len(args['child_ages'])))

        applicant = Applicant(filing_status=filing_status,
                              dependent=dependents,
                              earned_income=args['earned_income'],
                              spouse_earned_income=args['spouse_earned_income'],
                              federal_adjusted_gross_income=args['federal_adjusted_gross_income'],
                              federal_cdctc=args['federal_cdctc'],
                              federal_cdctc_before_tax_liability=args['federal_cdctc_before_tax_liability'],
                              federal_tax_liability=args['federal_tax_liability'],
                              state_adjusted_gross_income=args['state_adjusted_gross_income'],
                              state_tax_liability=args['state_tax_liability'],
                              net_income=args['net_income'],
                              spouse_net_income=args['spouse_net_income'],
                              certified_early_child_expense_amount=args['certified_early_child_expense_amount'],
                              household_size=args['household_size'])

        total_state_cdctc, total_refundable_amt, forms = STATE_CALCULATOR.calculate(applicant, args['state'])

        args['total_state_cdctc'] = np.array(round(total_state_cdctc))
        args['total_refundable_amt'] = np.array(round(total_refundable_amt))

    except Exception as e:
        logger.exception(f"exception: {e}", exc_info=True)
        raise e