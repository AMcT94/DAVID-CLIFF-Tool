from us_benefits_calculator.benefit_names import BenefitNames
from us_benefits_calculator.controller.controller import Controller
from us_benefits_calculator.utils import STATE_ID_TO_ABBREVIATION
import logging
import numpy as np

logger = logging.getLogger(__name__)


def initialize_calculate_store(args):
    """
    This method is called from the computation engine to calculate all benefits. It uses the Controller singleton

    :param args: Dict[str, Any]
    :return:
    """
    try:
        if "state_id" in args:
            args["state"] = STATE_ID_TO_ABBREVIATION[args["state_id"]]
        family_data = dict(
            annual_income=args["annual_earned_income"],
            dependents_age=args["child_ages"],
            children_accept_medicaid=args["children_accept_medicaid"],
            adult_accept_medicaid=args["adult_accept_medicaid"],
            household_accept_tanf=args["household_accept_tanf"],
            household_accept_snap=args["household_accept_snap"],
            household_size=args["household_size"],
            state_abbreviation=args["state"],
            household_has_mother=args["household_has_mother"],
        )
        options = {'debug_wic': args["debug_wic"], BenefitNames.WIC.value: True}
        all_benefit_results = Controller.calculate_household_benefits(family_data, options)
        # each benefit results
        args["total_monthly_wic_benefit"] = np.array(all_benefit_results[BenefitNames.WIC.value]['monthly_benefit'])
    except Exception as e:
        logger.exception(f"exception: {e}", exc_info=True)
        raise e
