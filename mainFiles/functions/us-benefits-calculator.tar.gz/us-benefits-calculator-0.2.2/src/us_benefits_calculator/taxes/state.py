import json
from us_benefits_calculator import get_full_path
from us_benefits_calculator.taxes.applicant import Applicant
class State:

    def __init__(self, parameters=[]):
        self.parameters = parameters

    def select_calculators(self, applicant):
        result = []
        state_calculator_list = self.parameters
        for calculator in state_calculator_list:
            # some calculators have eligibility constraints
            if "eligibility" in calculator:
                constraints = calculator["eligibility"]
                # check applicant eligibile for calculator
                if self.is_eligible(applicant, constraints):
                    result.append(calculator["calculator"])
            else:
                result.append(calculator["calculator"]) # calculator does not have any eligibility constraints
        return result # list of calculator(s) to calc state cdctc

    def is_eligible(self, applicant, constraints):
        value_dict = {
            "federal_adjusted_gross_income": applicant.federal_adjusted_gross_income,
            "federal_tax_liability": applicant.federal_tax_liability,
            # 'Net income' isn't very clear. Net of what? What's being subtracted from what?
            # it's only being used for Iowa's CDCTC, so we are just going to use the state AGI
            "net_income": applicant.net_income,
            "state_adjusted_gross_income": applicant.state_adjusted_gross_income,
            "certified_early_child_expense_amount": applicant.certified_early_child_expense_amount,
            "household_net_income": applicant.household_net_income,
            "household_size": applicant.household_size
        }
        for constraint in constraints:
            # TODO: IF MFJ, ADD SPOUSE INCOME
            if "filing_status" in constraint and applicant.filing_status.value != constraint.get("filing_status"):
                return False
            constraint_type = constraint.get("constraint_type")
            constraint_value = value_dict.get(constraint_type)
            if constraint_value is None:
                raise Exception(f"Applicant Input {constraint_type} is required")
            lower_limit = constraint["range"].get("lower_limit") # exclusive
            upper_limit = constraint["range"].get("upper_limit") # inclusive
            equal_limit = constraint["range"].get("equals")
            # no upper limit to measure against, only lower limit provided
            if equal_limit is not None:
                if equal_limit != constraint_value:
                    return False
                else:
                    continue
            if upper_limit is None:
                if lower_limit < constraint_value:
                    continue
                else:
                    return False
            elif lower_limit < constraint_value <= upper_limit:
                continue
            else:
                return False
        return True
