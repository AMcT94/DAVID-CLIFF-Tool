import argparse
import datetime
import json
import logging
import numpy as np
import re
from dateutil.parser import parse
from dateutil.relativedelta import relativedelta
from us_benefits_calculator import get_full_path
from us_benefits_calculator.utils import julian_date_to_date, get_poverty_level, STATE_ID_TO_ABBREVIATION


logger = logging.getLogger(__name__)

STATE_REFERENCE_PARAMETERS = {}


def load_test_data(filename, field_count):
    result = {}
    with open(filename) as f:
        lines = f.readlines()
        columns = lines[0].rstrip().split(',')


def initialize(parameters=None):
    global STATE_REFERENCE_PARAMETERS
    if parameters is None:
        if not STATE_REFERENCE_PARAMETERS:
            with open(get_full_path('tanf.json')) as parameters_file:
                STATE_REFERENCE_PARAMETERS = json.load(parameters_file)
    else:
        STATE_REFERENCE_PARAMETERS = parameters


def print_type_combinations():
    comparison_fields = ['program', 'coverage', 'unit_type', 'component']
    combinations = {}

    for f in comparison_fields:
        combinations[f] = {}

    for state, state_data in STATE_REFERENCE_PARAMETERS.items():
        for table, data in state_data.items():
            # print(f"{table} - {data}")
            # all the data in "asset_test"
            for f in comparison_fields:
                all_types = {}
                for d in data:
                    if isinstance(d[f], list):
                        all_types[";".join(d[f])] = ""
                    else:
                        all_types[d[f]] = ""

                l = list(all_types.keys())
                l.sort()
                combinations[f][";".join(l)] = ""

    for f in comparison_fields:
        print(f"\n--------- {f} --------- ")
        l = list(combinations[f].keys())
        l.sort()
        for i in l:
            print(f" -> {i}")


def get_majority_rule(state, datatype):
    state_data = STATE_REFERENCE_PARAMETERS[state]
    return get_majority_rule_from_data(state_data[datatype], datatype)


def get_majority_rule_from_data(data):
    for row in data:
        if row['majority_rules']:
            return row


def determine_exemption(family):
    # TODO!!
    return False


def select_rule(state_element, family, is_recipient_forced=None):
    majority_rule = get_majority_rule_from_data(state_element)

    if len(state_element) == 1:
        # There is only majority rule, so we can skip the following
        return majority_rule['data']

    is_exempt = determine_exemption(family)  # TODO

    filtered_rules = []
    for rule in state_element:
        if rule['component'] == 'exempt' and not is_exempt:
            continue
        if rule['component'] == 'non-exempt' and is_exempt:
            continue

        if rule['component'] != majority_rule['component'] and rule['component'] not in ['exempt', 'non-exempt', '']:
            continue
        if rule['coverage'] != majority_rule['coverage']:
            continue

        # We don't care if it's 'TANF' or a 'state program'
        #     and \
        # rule['program'] == majority_rule['program']:
        filtered_rules.append(rule)
        # actually...maybe make a map for each unit type to the rule

    if len(filtered_rules) == 1:
        # Other rules describe different areas or programs, so we just return the majority rule
        return filtered_rules[0]['data']

    if len(filtered_rules) == 2 and \
            filtered_rules[0]['component'] == filtered_rules[1]['component'] and \
            filtered_rules[0]['coverage'] == filtered_rules[1]['coverage'] and \
            filtered_rules[0]['unit_type'] == filtered_rules[1]['unit_type'] and \
            filtered_rules[0]['program'] != filtered_rules[1]['program']:
        # NH has a state program and tanf for eligibility_of_individual_family_members
        return majority_rule['data']

    unit_types = {}
    for rule in filtered_rules:
        for unit_type in rule['unit_type']:
            unit_types[unit_type] = rule

    ut = list(unit_types.keys())
    ut.sort()

    if is_recipient_forced is not None:
        is_recipient = is_recipient_forced
    else:
        is_recipient = family['history']['is_recipient']

    def has_earned_income():
        return 'earned_income' in family['monthly_income'] and family['monthly_income']['earned_income']

    # These lists are made by inspection of the data.
    if ut == ['applicants', 'recipients']:
        if is_recipient:
            result = unit_types['recipients']
        else:
            result = unit_types['applicants']

    elif ut == ['applicants', 'recipients_who_become_employed_during_assistance',
                'recipients_who_do_notbecome_employed_during_assistance']:
        if is_recipient:
            # TODO: don't have enough input to figure this out
            result = unit_types['recipients_who_become_employed_during_assistance']
        else:
            result = unit_types['applicants']

    elif ut == ['applicants', 'recipients_with_earnings', 'recipients_without_earnings']:
        if is_recipient:
            if has_earned_income():
                result = unit_types['recipients_with_earnings']
            else:
                result = unit_types['recipients_without_earnings']
        else:
            result = unit_types['applicants']
    elif ut == ['individuals_employed_at_least_20hours_per_week', 'individuals_employed_less_than_20hours_per_week']:

        # TODO: don't have enough input to figure this out
        if has_earned_income():
            result = unit_types['individuals_employed_at_least_20hours_per_week']
        else:
            result = unit_types['individuals_employed_less_than_20hours_per_week']

    elif ut == ['individuals_employed_at_least_30hours_per_week', 'individuals_employed_less_than_30hours_per_week']:

        # TODO: don't have enough input to figure this out
        if has_earned_income():
            result = unit_types['individuals_employed_at_least_30hours_per_week']
        else:
            result = unit_types['individuals_employed_less_than_30hours_per_week']

    elif ut == ['other', 'two_parent_families']:
        if family['parent_count'] == 2:
            result = unit_types['two_parent_families']
        else:
            result = unit_types['other']

    elif ut == ['married_couple_with_a_common_child', 'other']:
        # TODO: don't have enough input to figure this out - assume married
        if family['parent_count'] == 2 and family['child_count'] > 0:
            result = unit_types['married_couple_with_a_common_child']
        else:
            result = unit_types['other']

    elif ut == ['child_only_units', 'one_parent_or_one_caretaker_families', 'two_parent_families']:
        if family['parent_count'] == 0:
            result = unit_types['child_only_units']
        elif family['parent_count'] == 1:
            result = unit_types['one_parent_or_one_caretaker_families']
        else:
            result = unit_types['two_parent_families']

    elif ut == ['applicants', 'recipient_in_first_or_second_month_of_benefits',
                'recipient_in_third_or_subsequent_month_of_benefits']:
        if is_recipient:
            if family['history']['months_of_assistance'] <= 2:
                result = unit_types['recipient_in_first_or_second_month_of_benefits']
            else:
                result = unit_types['recipient_in_third_or_subsequent_month_of_benefits']
        else:
            result = unit_types['applicants']
    elif ut == ['recipients_with_earned_and_unearned_income', 'recipients_with_earned_income_only',
                'recipients_without_earnings']:
        if not is_recipient:
            raise ValueError(f"Unexpected family to be recipient for family {family}")

        if has_earned_income:

            if family['monthly_income']['earned_income'] == sum(family['monthly_income'].values()):
                result = unit_types['recipients_with_earned_income_only']
            else:
                result = unit_types['recipients_with_earned_and_unearned_income']

        else:
            result = unit_types['recipients_without_earnings']

    elif ut == ['recipients_with_earned_income_only', 'recipients_without_earnings']:
        if not is_recipient:
            raise ValueError(f"Unexpected family to be recipient for family {family}")

        if has_earned_income:
            result = unit_types['recipients_with_earned_income_only']
        else:
            result = unit_types['recipients_without_earnings']

    elif ut == ['child_only_units', 'other']:
        if family['parent_count'] == 0:
            result = unit_types['child_only_units']
        else:
            result = unit_types['other']

    elif ut == ['child_only_units_with_disqualified_parent_or_caretaker',
                'child_only_units_without_parent_or_caretaker', 'other']:
        # TODO: don't have enough input to figure this out - number of disqualified parents
        if family['parent_count'] == 0:
            result = unit_types['child_only_units_without_parent_or_caretaker']
        else:
            result = unit_types['other']

    elif ut == ['child_only_units_with_ineligible_parent', 'child_only_units_with_relative_caretaker', 'other']:
        # TODO: don't have enough input to figure this out - number of disqualified parents
        if family['parent_count'] == 0:
            result = unit_types['child_only_units_with_ineligible_parent']
        else:
            result = unit_types['other']

    elif ut == ['applicants', 'other', 'two_parent_families']:
        if not is_recipient:
            result = unit_types['applicants']
        elif family['parent_count'] == 2:
            result = unit_types['two_parent_families']
        else:
            result = unit_types['other']

    elif ut == ['child_only_units_with_elderly_infirm_or_caring_caretaker', 'unit_with_healthy_uncaring_caretaker']:
        # TODO: don't have enough input to figure this out - elderly/infirm caretaker
        # if family['parent_count'] == 0 and ...:
        #     result = unit_types['child_only_units_without_parent_or_caretaker']
        # else:
        #     result = unit_types['unit_with_healthy_uncaring_caretaker']

        result = unit_types['unit_with_healthy_uncaring_caretaker']
    else:
        raise ValueError(f"Unknown unit type split: {ut}")

    return result['data']


def get_best_rule(state_data, datatype, family, is_recipient=None):
    # print(f" - selecting type {datatype}")
    # TODO: try finding a rule that better fits the family...
    #  - is there a geographical split? If so, find the geography for the majority rule and filter to those
    #  - only 'other' components?
    #  - choose unit type

    return select_rule(state_data[datatype], family, is_recipient_forced=is_recipient)


# TODO:
# class Family(object):


def determine_assistance_unit(state_data, state, year, family, calculation_year, calculation_month, history,
                              include_adults_needs=True, include_adults_income=True):
    # no filtering yet?
    # add a unit type? maybe at least
    # applicant vs recipient
    # child_only_units;one_parent_or_one_caretaker_families;two_parent_families
    # child_only_units;other
    # child_only_units_with_disqualified_parent_or_caretaker;child_only_units_without_parent_or_caretaker;other
    # child_only_units_with_elderly_infirm_or_caring_caretaker;unit_with_healthy_uncaring_caretaker
    # child_only_units_with_ineligible_parent;child_only_units_with_relative_caretaker;other
    # other;two_parent_families
    # married_couple_with_a_common_child;other
    assistance_unit = dict(family)

    # TODO: this should be populated by inputted history
    assistance_unit['history'] = summarize_history(history)

    if 'adults' not in assistance_unit or assistance_unit['adults'] is None:
        assistance_unit['adults'] = []

    if 'children' not in assistance_unit or assistance_unit['children'] is None:
        assistance_unit['children'] = []

    eligibility_rules = get_best_rule(state_data, 'eligibility_of_individual_family_members', assistance_unit)

    monthly_income = {
        'earned_income': 0,
        'unearned_income': 0
    }

    assets = {
        'cash': 0
    }

    #

    # "ssi_income_counted": "non_ssi_income",
    # "ssi_income_counted_note": "All adult recipients? income (SSI and non-SSI) is counted. Child recipients? earnings and SSI payments are not counted. For eligible families who receive cash payments, the payment does not vary by income or family size.  Also, recipients of SSI and Social Security Disability payments are not considered W-2 participants.",
    # "ssi_income_counted_note": "If a child receiving SSI is included in the unit, the share of his or her SSI benefit equal to the need standard increment for an additional child (regardless of the size of the assistance unit) is counted as income. All RSDI benefits received by the child are also counted.",
    # "ssi_income_counted_note": "SSI benefits received by dependent children are not counted.",
    # "ssi_income_counted_note": "The child support income of a child SSI recipient residing in the household does not count towards the net income test.",
    # "ssi_income_counted_note": "The SSI income and other assets are counted if the person receiving SSI is part of a one-parent household, a two-parent household, or a caretaker household with only one child in the unit. In a caretaker household with multiple children, if any child receives SSI, that income is not counted.",
    # "ssi_income_counted_note": "While the SSI recipient's SSI allocation is not counted, the non-SSI income and assets of the individual are counted.",
    # "ssi_income_counted": "other",

    # "ssi_recipients_in_unit": "all",
    # "ssi_recipients_in_unit": "children_only",
    # "ssi_recipients_in_unit": "none",
    # "ssi_recipients_in_unit_note": "A child under the age of 18 receiving SSI may be included in the unit at the caretaker?s request.",
    # "ssi_recipients_in_unit_note": "Cases where all adults receive SSI shall be reviewed at least once every 24 months.",
    # "ssi_recipients_in_unit_note": "Individuals in receipt of Supplemental Security Income (SSI), including presumptive SSI, are not included as members of the TANF household.",
    # "ssi_recipients_in_unit_note": "Individuals receiving supplemental aid to the blind are also excluded in determining eligibility and income for the unit.",
    # "ssi_recipients_in_unit_note": "Person who receives Aid for the Aged, Blind, and Disabled (state program) are also ineligible.",
    # "ssi_recipients_in_unit_note": "SSI income is counted in the financial eligibility test if received by an adult, but not if received by a child.  For eligible families who receive cash payments, the payment does not vary by income or family size.  Also, recipients of SSI and Social Security Disability payments are not considered W-2 participants.",
    # "ssi_recipients_in_unit_note": "SSI is counted as unearned income in month received.",

    eligible_adults = []

    if include_adults_needs:
        for adult in assistance_unit['adults']:
            if eligibility_rules['ssi_recipients_in_unit'] != 'all' and adult.get_income_amount('ssi') > 0:
                continue

            eligible_adults.append(adult)

    if include_adults_income:
        for adult in assistance_unit['adults']:
            if eligibility_rules['ssi_recipients_in_unit'] != 'all' and adult.get_income_amount('ssi') > 0:
                continue

            for income_type, income_amount in adult.get_income().items():
                if income_type not in monthly_income:
                    monthly_income[income_type] = 0

                # TODO: do we assume that monthly_income is reported for annual amounts?
                monthly_income[income_type] = monthly_income[income_type] + (income_amount / 12)

            # TODO: assets only for counted adults?
            for asset_type, asset_amount in adult.get_assets().items():
                assets[asset_type] = assets[asset_type] + asset_amount

    eligible_children = []
    for child in assistance_unit['children']:
        first_of_month = datetime.datetime(int(calculation_year), calculation_month, 1)
        parsed_birthdate = child.get_birthdate()
        age = relativedelta(first_of_month, parsed_birthdate).years
        comparison_age = None
        if 'child_under' in eligibility_rules:
            comparison_age = eligibility_rules['child_under']

        child_in_school = True  # TODO: assuming that kids are in school
        if 'child_in_school_under' in eligibility_rules and child_in_school:
            comparison_age = eligibility_rules['child_in_school_under']

        if comparison_age is None:
            raise ValueError(f"No child age limit for {state}")

        if age < comparison_age:
            eligible_children.append(child)

    adult_count = len(eligible_adults)
    children_count = len(eligible_children)
    assistance_unit['assets'] = assets
    assistance_unit['monthly_income'] = monthly_income
    assistance_unit['family_size'] = adult_count + children_count
    assistance_unit['parent_count'] = adult_count
    assistance_unit['child_count'] = children_count
    assistance_unit['fpl'] = get_poverty_level(year, state, assistance_unit['family_size'])/12

    return assistance_unit


def determine_income_eligibility(state_data, assistance_unit, history):
    gross_monthly_income = sum(assistance_unit['monthly_income'].values())

    tests = get_best_rule(state_data, 'income_eligibility_tests', assistance_unit)
    dollar_amounts = get_best_rule(state_data, 'dollar_amounts', assistance_unit)

    is_eligible = True
    test_results = []
    for test in tests:
        # TODO: check unit type fits?
        if test['type'] == 'gross_income':
            income = gross_monthly_income
            disregards_used = 0
        elif test['type'] == 'net_income':
            net_monthly_income, disregards = determine_netincome_and_disregards(state_data, assistance_unit,
                                                                                'net_income_test', history)
            income = net_monthly_income
            disregards_used = disregards
        elif test['type'] == 'gross_earnings':
            income = assistance_unit['monthly_income']['earned_income']
            disregards_used = 0
        elif test['type'] == 'unearned_income':
            income = assistance_unit['monthly_income']['unearned_income']
            disregards_used = 0
        else:
            raise ValueError(f"Unexpected income_eligibility_tests income: \"{test['type']}\"")

        if test['standard']['name'] == 'fpl':
            threshold = test['multiplier'] * assistance_unit['fpl']
        else:
            threshold = test['multiplier'] * get_amount_from_dollar_amount(assistance_unit['family_size'],
                                                                           dollar_amounts, test['standard']['index'])

        e = income < threshold

        test_results.append({
            'threshold': threshold,
            'income': income,
            'income_disregards': disregards_used,
            'is_eligible': e
        })
        is_eligible = e and is_eligible

    return {
        'is_eligible': is_eligible,
        'test_results': test_results
    }


def calculation_months_of_use(history, disregard_use, disregard_index, duration_limit=None):
    months_of_use = 0
    # print(history)
    months_evalulated = 0
    consecutive_months_of_use = 0
    found_break = False
    if disregard_use == 'benefit_computation':
        for i, e in reversed(list(enumerate(history))):
            months_evalulated = months_evalulated + 1
            if disregard_index in e['benefits']['income_disregards']:
                months_of_use = months_of_use + 1
                if not found_break:
                    consecutive_months_of_use = consecutive_months_of_use + 1
            else:
                found_break = True
            if duration_limit is not None and months_evalulated >= duration_limit:
                return months_of_use, consecutive_months_of_use
    elif disregard_use == 'net_income_test':
        for i, e in reversed(list(enumerate(history))):
            months_evalulated = months_evalulated + 1
            for t in e['eligibility']['test_results']:
                if disregard_index in t['income_disregards']:
                    months_of_use = months_of_use + 1
                    if not found_break:
                        consecutive_months_of_use = consecutive_months_of_use + 1
                else:
                    found_break = True
                if duration_limit is not None and months_evalulated >= duration_limit:
                    return months_of_use, consecutive_months_of_use
    else:
        raise ValueError(f"Unexpected disregard_use {disregard_use}")

    return months_of_use, consecutive_months_of_use


def matches_time_range(assistance_unit, history, disregard_use, time_range, disregard_index, unavailable_disregards,
                       apply_conditional_time_ranges):
    if len(time_range) == 0:
        return True  # If there are none defined, there is no check

    for time in time_range:
        ###############################################################################################################
        # Some time ranges have special conditions that apply to them along with a 'duration_in_months'. Here we
        # defer to the caller to see if the special conditions are true
        ###############################################################################################################
        if 'conditions' in time:
            if apply_conditional_time_ranges:
                months_of_use, consecutive_months_of_use = calculation_months_of_use(history, disregard_use,
                                                                                     disregard_index,
                                                                                     duration_limit=time[
                                                                                         'duration_in_months'])
                # print(f"eval condition: {months_of_use < time['duration_in_months']} {months_of_use} {time['duration_in_months']}")
                if consecutive_months_of_use < time['duration_in_months']:
                    return True
            # Either we aren't using conditional time ranges or we aren't in the duration period for this time range
            continue

        ###############################################################################################################
        # The first type of disregard is allow for X months over a time period (either a number of months or lifetime)
        ###############################################################################################################
        if 'limit_type' in time:
            if time['limit_type'] == 'months':
                # {'duration_in_months': 3, 'limit_type': 'months', 'limit_duration': 12, 'consecutive': True}
                duration_months_of_use, consecutive_months_of_use = calculation_months_of_use(history, disregard_use,
                                                                                              disregard_index,
                                                                                              duration_limit=time[
                                                                                                  'limit_duration'])
                if 'consecutive' in time and time['consecutive']:
                    months_of_use = consecutive_months_of_use
                else:
                    months_of_use = duration_months_of_use

            elif time['limit_type'] == 'lifetime':
                # {'duration_in_months': 4, 'limit_type': 'lifetime'}
                months_of_use, consecutive_months_of_use = calculation_months_of_use(history, disregard_use,
                                                                                     disregard_index)
            else:
                raise ValueError(f"Unexpected time range limit type: {time['limit_type']}")

            # limit = time['limit_duration'] if 'limit_duration' in time else 'N/A'
            if months_of_use < time['duration_in_months']:
                # print(f"{disregard_index} - OK - {disregard_use} use: {months_of_use}, limit: {limit}")
                return True
            else:
                # print(f"{disregard_index} - NOT OK - {disregard_use} use: {months_of_use}, limit: {limit}")
                continue

        ###############################################################################################################
        # The next type of disregard is allowed after another disregard has expired
        ###############################################################################################################
        if 'after_expiration_of_index' in time:
            if time['after_expiration_of_index'] in unavailable_disregards:
                return True
            else:
                continue

        ###############################################################################################################
        # The remaining types are simpler - there's a month range (start/end month) of either earnings or assistance
        ###############################################################################################################
        if 'type' not in time:
            raise ValueError(f"WARNING: missing time type on {time}")

        if 'start_month' not in time and 'end_month' not in time:
            return True

        if time['type'] == 'assistance':
            value = assistance_unit['history']['months_of_assistance'] + 1
        elif time['type'] == 'earnings':
            value = assistance_unit['history']['months_of_earnings'] + 1
        else:
            raise ValueError(f"Unexpected time range type: {time['type']}")

        if value is not None:
            if 'start_month' not in time and value <= time['end_month']:
                return True
            if 'end_month' not in time and time['start_month'] <= value:
                return True
            if time['start_month'] <= value <= time['end_month']:
                return True

    return False


def get_dollar_amount(state_data, dollar_amount_name, family, is_recipient=None):
    rule = get_best_rule(state_data, "dollar_amounts", family, is_recipient=is_recipient)

    for dollar_amount in rule:
        if dollar_amount['name'] == dollar_amount_name:
            amounts = dollar_amount['amounts']
            return amounts[min(len(amounts), family['family_size']) - 1]

    raise ValueError(f"Unable to find dollar amount {dollar_amount_name}")


def determine_netincome_and_disregards(state_data, assistance_unit, disregard_use, history, is_recipient=None,
                                       apply_conditional_time_ranges=False):
    # 'benefit_computation', 'net_income_test'

    disregards = get_best_rule(state_data, 'earned_income_disregards', assistance_unit, is_recipient=is_recipient)
    net_income = dict(assistance_unit['monthly_income'])
    disregard_amounts = {}
    unavailable_disregards = {}
    for i in range(len(disregards['income_disregards'])):
        disregard = disregards['income_disregards'][i]
        if disregard_use not in disregard['use']:
            continue

        matches_one_time_range = matches_time_range(assistance_unit, history, disregard_use, disregard['time_range'], i,
                                                    unavailable_disregards, apply_conditional_time_ranges)
        # "6 months over a lifetime": [{'duration_in_months': 4, 'limit_type': 'lifetime'}],
        if not matches_one_time_range:
            unavailable_disregards[i] = True  # TODO: Comment?
            continue

        if 'type' in disregard and disregard['type'] == 'greater_of':
            possible_amounts = []
            for a in disregard['amounts']:
                possible_amounts.append(
                    extract_disregard_amount(state_data, assistance_unit, a, net_income['earned_income'], is_recipient))
            amount = max(possible_amounts)
        else:
            amount = extract_disregard_amount(state_data, assistance_unit, disregard, net_income['earned_income'],
                                              is_recipient)

        disregard_amount = min(amount, net_income['earned_income'])
        net_income['earned_income'] = net_income['earned_income'] - disregard_amount
        disregard_amounts[i] = disregard_amount

    net_monthly_income = 0
    for income_type, income_amount in net_income.items():
        # TODO filter excluded income
        net_monthly_income = net_monthly_income + income_amount

    return net_monthly_income, disregard_amounts


def extract_disregard_amount(state_data, assistance_unit, disregard, earned_income, is_recipient):
    if 'amount_by_household_size' in disregard:
        amount_by_household_size = disregard['amount_by_household_size']
        amount = amount_by_household_size[min(len(amount_by_household_size), assistance_unit['family_size']) - 1]
    elif 'amount' in disregard:
        amount = disregard['amount']
    elif 'amount_note' in disregard and disregard[
        'amount_note'] == "Difference between 50 percent of the current Federal Poverty Level for the applicant's family size and their TANF payment level.":
        amount = (assistance_unit['fpl'] * 50.0 / 100.0) - get_dollar_amount(state_data, "Payment Standard",
                                                                             assistance_unit, is_recipient=is_recipient)
        amount = max(0.0, amount)
    else:
        raise ValueError(f"WARNING: no amount in {disregard}")

    # TODO: amount note:
    # Deduction is allowed for each employed person in the unit.

    lower_limit = 0
    upper_limit = earned_income

    def extract_dollar_range_amount(limit):
        if limit == 'fpl':
            return assistance_unit['fpl']
        else:
            return limit

    if "dollar_range" in disregard:
        dollar_range = disregard['dollar_range']
        if 'lower_limit' in dollar_range:
            lower_limit = max(lower_limit, extract_dollar_range_amount(dollar_range['lower_limit']))

        if 'upper_limit' in dollar_range:
            upper_limit = min(upper_limit, extract_dollar_range_amount(dollar_range['upper_limit']))

    if 'type' in disregard and disregard['type'] == 'percent':
        amount = (upper_limit - lower_limit) * amount / 100
    return amount


def condition_history(history, disregard_index):
    last_cash_benefit = history[len(history) - 1]['benefits']['cash_benefit']
    is_recipient = last_cash_benefit > 0
    previous_month_earnings = history[len(history) - 1]['assistance_unit']['monthly_income']['earned_income']

    months_of_break_since_last_use = [0]  # keeps track of months of CONSECUTIVE break
    previous_recipient = False
    previously_used_disregard = False
    for month_history in reversed(list(history)):
        # print(month_history['benefits']['cash_benefit'])
        if month_history['benefits']['cash_benefit'] == 0.0:
            # TODO: in theory, there could be gaps in benefits that would lead to a larger gap amount....
            if not previously_used_disregard:
                months_of_break_since_last_use[-1] = months_of_break_since_last_use[-1] + 1
        else:
            if disregard_index in month_history['benefits']['income_disregards']:
                # print("DISREGARD USED")
                previously_used_disregard = True

            previous_recipient = True
            months_of_break_since_last_use.append(0)

    return is_recipient, previous_month_earnings, max(months_of_break_since_last_use), previously_used_disregard


def determine_benefits_with_conditional_disregard(state_data, assistance_unit, history, benefit_computations,
                                                  dollar_amounts, conditional_time_range):
    unearned_monthly_income = 0  # TODO

    if len(conditional_time_range) != 1:
        raise ValueError(f"There should only be one conditional time range")

    if len(history) == 0:
        # All conditions are based on previous benefits. If this is the first month of benefits, just calculate the default
        return determine_benefits_impl(state_data, assistance_unit, history, benefit_computations, dollar_amounts)

    time_range = conditional_time_range[0]['time_range']
    disregard_index = conditional_time_range[0]['disregard_index']
    is_recipient, previous_month_earnings, months_of_break_since_last_use, previously_used_disregard = condition_history(
        history, disregard_index)

    default_net_monthly_income, default_disregards, default_cash_benefit, default_calculations = determine_benefits_impl(
        state_data, assistance_unit, history, benefit_computations, dollar_amounts)
    cond_net_monthly_income, cond_disregards, cond_cash_benefit, cond_calculations = determine_benefits_impl(state_data,
                                                                                                             assistance_unit,
                                                                                                             history,
                                                                                                             benefit_computations,
                                                                                                             dollar_amounts,
                                                                                                             apply_conditional_time_ranges=True)

    conditional_time_range_applies = []
    for condition in time_range['conditions']:
        earnings_increased = (assistance_unit['monthly_income']['earned_income'] > previous_month_earnings)
        benefits_decreased = default_cash_benefit < cond_cash_benefit
        months_of_use, consecutive_months_of_use = calculation_months_of_use(history, 'benefit_computation',
                                                                             disregard_index)

        if condition['type'] == 'earnings_increase_lowers_benefits':
            result = (earnings_increased and benefits_decreased) or (
                    0 < consecutive_months_of_use < time_range['duration_in_months'])
            # print(f" {condition['type']} -- {result}:  ({earnings_increased} && {benefits_decreased}) OR {0 < consecutive_months_of_use < time_range['duration_in_months']}")
            conditional_time_range_applies.append(result)
        elif condition['type'] == 'case_subject_to_closure':
            # print(f" {condition['type']} -- {is_recipient and (default_cash_benefit == 0) }")
            conditional_time_range_applies.append(is_recipient and (default_cash_benefit == 0))

        elif condition['type'] == 'break_required':
            result = (not previously_used_disregard) or (
                    months_of_break_since_last_use > condition['break_duration_in_months']) or (
                             0 < consecutive_months_of_use < time_range['duration_in_months'])

            # print(f"{result} ==> {condition['type']} -- { previously_used_disregard} {months_of_break_since_last_use} > {condition['break_duration_in_months']}")
            conditional_time_range_applies.append(result)
        else:
            raise ValueError(f"Unknown condition type: {condition['type']}")

    # 'duration_in_months': 2, 'conditions': [{'type': 'earnings_increase_lowers_benefits'}]
    # 'duration_in_months': subject_to_closure[time],
    # {'type': 'case_subject_to_closure'},
    # {'type': 'break_required', 'break_duration_in_months': 12}

    if all(conditional_time_range_applies):
        return cond_net_monthly_income, cond_disregards, cond_cash_benefit, cond_calculations
    else:
        return default_net_monthly_income, default_disregards, default_cash_benefit, default_calculations


def determine_benefits_impl(state_data, assistance_unit, history, benefit_computations, dollar_amounts,
                            apply_conditional_time_ranges=False):
    unearned_monthly_income = 0  # TODO

    net_monthly_income, disregards = determine_netincome_and_disregards(state_data, assistance_unit,
                                                                        'benefit_computation', history,
                                                                        is_recipient=True,
                                                                        apply_conditional_time_ranges=apply_conditional_time_ranges)

    cash_benefit, calculations = calculate_benefit(assistance_unit['fpl'], benefit_computations, dollar_amounts,
                                                   assistance_unit['family_size'],
                                                   net_monthly_income, unearned_monthly_income)

    return net_monthly_income, disregards, cash_benefit, calculations


def select_conditional_time_range(state_data, assistance_unit):
    disregards = get_best_rule(state_data, 'earned_income_disregards', assistance_unit, is_recipient=True)
    result = []
    for i in range(len(disregards['income_disregards'])):
        disregard = disregards['income_disregards'][i]
        for t in disregard['time_range']:
            if 'conditions' in t:
                result.append({'disregard_index': i, 'time_range': t})

    return result


def determine_benefits(state_data, assistance_unit, history):
    benefit_computations = get_best_rule(state_data, 'benefit_computation', assistance_unit, is_recipient=True)
    dollar_amounts = get_best_rule(state_data, 'dollar_amounts', assistance_unit, is_recipient=True)

    technically_eligible = False  # TODO

    conditional_time_range = select_conditional_time_range(state_data, assistance_unit)
    if len(conditional_time_range) > 0:
        net_monthly_income, disregards, cash_benefit, calculations = \
            determine_benefits_with_conditional_disregard(state_data, assistance_unit, history, benefit_computations,
                                                          dollar_amounts, conditional_time_range)
    else:
        net_monthly_income, disregards, cash_benefit, calculations = \
            determine_benefits_impl(state_data, assistance_unit, history, benefit_computations, dollar_amounts)

    # TODO: minimum_benefit_for_technical_eligibility
    # TODO minimum_benefit
    return {
        # 'technically_eligible': cash_benefit > ,
        'net_monthly_income': net_monthly_income,
        'income_disregards': disregards,
        'cash_benefit': cash_benefit,
        'calculations': calculations
    }


def calculate_benefit(assistance_unit_fpl, benefit_rule, dollar_amounts, family_size, net_monthly_income,
                      unearned_monthly_income):
    calculations = []
    cash_amounts = []
    for formula in benefit_rule['formulas']:
        # standard =  growAmount(standard, data_year, grow_to_year, REAL_WAGE_GROWTH_RATE)
        if formula['standard_type'] == 'fpl':
            standard = assistance_unit_fpl
        else:
            standard = get_amount_from_dollar_amount(family_size, dollar_amounts,
                                                     formula['standard_type']['dollar_amount'])
        cash = ((formula['standard_multiplier'] * standard) - (formula['income_multiplier'] * net_monthly_income) - (
                formula['unearned_income_multiplier'] * unearned_monthly_income)) * formula[
                   'standard_and_income_multiplier']
        cash_amount = max(0.0, cash)
        cash_amounts.append(cash_amount)
        calculations.append({
            'cash_benefit_amount': cash_amount,
            'standard': formula['standard_name'] if 'standard_name' in formula else '',
        })
    cash_benefit = min(cash_amounts)
    return cash_benefit, calculations


def get_amount_from_dollar_amount(family_size, dollar_amounts, dollar_amount_index):
    standard_scale = dollar_amounts[dollar_amount_index]['amounts']
    family_size = min(family_size, len(standard_scale)) - 1
    standard = standard_scale[family_size]
    return standard


def summarize_history(history, months_to_consider_limit=None):
    result = {
        'months_of_assistance': 0,
        'months_of_earnings': 0,
        'is_recipient': False
    }

    months_to_consider = len(history)
    if months_to_consider_limit is not None:
        months_to_consider = min(months_to_consider, int(months_to_consider_limit) - 1)

    reversed_history = reversed(history)
    i = 0
    for month in reversed_history:
        if i >= months_to_consider:
            break
        i = i + 1
        if 'earned_income' in month['assistance_unit']['monthly_income']:
            result['months_of_earnings'] = result['months_of_earnings'] + 1

        if month['benefits']['cash_benefit'] > 0:
            result['months_of_assistance'] = result['months_of_assistance'] + 1
            result['is_recipient'] = True
        else:
            result['is_recipient'] = False

    return result


def matches_assistance_unit(assistance_unit, is_exempt, time_limit_selector):
    non_exempt = not is_exempt

    def matches(rules):
        result = []
        for rule in rules:
            if rule == 'all':
                return True
            elif rule in ['non_exempt_recipient', 'non_exempt_unit']:
                result.append(non_exempt)
            elif rule in ['two_parent_units']:
                result.append(assistance_unit['parent_count'] == 2)
            elif rule in ['non_exempt_two_parent_un_under_employed_units']:
                # TODO un/under employed defined as having $0 in earned income
                result.append(non_exempt and assistance_unit['parent_count'] == 2 and assistance_unit['monthly_income'][
                    'earned_income'] == 0)
            elif rule in ['non_exempt_adult']:
                # TODO: I'm not sure if this is right
                result.append(non_exempt)
            elif rule in ['non_exempt_adults_without_allowed_work']:
                # TODO: ?? allowed work?
                result.append(non_exempt)
            elif rule == 'non_exempt_one_parent_units':
                result.append(non_exempt and assistance_unit['parent_count'] == 1)
            elif rule in ['childonly']:
                result.append(assistance_unit['parent_count'] == 0)
            elif rule in ['childonly_in_custody_of_state']:
                # TODO: I think this is right - should we ignore these?
                pass
            elif rule in ['minor_parent_in_supervised_setting', 'minor_parent']:
                pass
            elif rule in ['exempt_state_funded_recipients']:
                # TODO: Can we assume that recipients are state funded?
                result.append(is_exempt)
            elif rule in ['parent_excluded_due_to_technical_eligibility']:
                # TODO: ??
                pass
            elif rule in ['non_exempt_recipient_with_work_experience']:
                # TODO: ??
                pass
            elif rule in ['two_parent_capable_of_earning_500']:
                # TODO: ??
                pass
            elif rule in ['terminated_grant_due_to_work_requirement_noncompliance']:
                # TODO: ??
                pass
            else:
                raise ValueError(f"Unknown rule name {rule}")
        return any(result)

    includes_rules = time_limit_selector['assistance_units']['includes'] if 'includes' in time_limit_selector[
        'assistance_units'] else []
    excludes_rules = time_limit_selector['assistance_units']['excludes'] if 'excludes' in time_limit_selector[
        'assistance_units'] else []

    includes = matches(includes_rules)
    excludes = matches(excludes_rules)

    return includes and not excludes


def determine_time_limit_compliance(state_data, state, year, family, assistance_unit, calculation_year,
                                    calculation_month, new_history):
    time_limits = get_best_rule(state_data, 'time_limits', assistance_unit)
    is_exempt = determine_exemption(family)
    months_of_assistance = assistance_unit['history']['months_of_assistance']

    result = {
        'is_eligible': True
    }
    for limit in time_limits['limits']['lifetime_limits']:
        if matches_assistance_unit(assistance_unit, is_exempt, limit) and months_of_assistance >= limit[
            'maximum_months']:
            result['lifetime_limit_compliance'] = False
            result['is_eligible'] = False

    for limit in time_limits['limits']['benefit_reduction']:
        if matches_assistance_unit(assistance_unit, is_exempt, limit) and months_of_assistance >= limit[
            'months_of_assistance']:
            result['benefit_reduction'] = limit['benefit_reduction']
            if limit['benefit_reduction'] == 'unit_head_removed':
                result['assistance_unit'] = determine_assistance_unit(state_data, state, year, family, calculation_year,
                                                                      calculation_month, new_history,
                                                                      include_adults_income=False,
                                                                      include_adults_needs=False)
            elif limit['benefit_reduction'] == 'count_ineligible_individuals_income_not_needs':
                result['assistance_unit'] = determine_assistance_unit(state_data, state, year, family, calculation_year,
                                                                      calculation_month, new_history,
                                                                      include_adults_income=True,
                                                                      include_adults_needs=False)
            else:
                raise ValueError(f"Unexpected benefit_reduction {limit['benefit_reduction']}")

    for limit in time_limits['limits']['periodic_limits']:
        if matches_assistance_unit(assistance_unit, is_exempt, limit):
            h = summarize_history(new_history, months_to_consider_limit=limit['months_of_accumulation'])
            if h['months_of_assistance'] >= limit['months_of_assistance']:
                result['periodic_limit_compliance'] = False
                result['is_eligible'] = False

    for limit in time_limits['limits']['benefit_waiting_periods']:
        if matches_assistance_unit(assistance_unit, is_exempt, limit):
            h = summarize_history(new_history, months_to_consider_limit=limit['months_of_assistance'] + limit[
                'months_of_ineligibility'])
            if h['months_of_assistance'] >= limit['months_of_assistance']:
                result['benefit_waiting_periods_compliance'] = False
                result['is_eligible'] = False

    return result


def determine_eligibility_of_two_parent_families(state_data, assistance_unit):
    result = {}
    eligibility_of_two_parent_families = get_best_rule(state_data, 'eligibility_of_two_parent_families',
                                                       assistance_unit)
    if assistance_unit['parent_count'] == 2 and eligibility_of_two_parent_families['eligible'] != 'all':
        # TODO: There are more complicated rules for a couple of states - especially in regard to disability
        result['is_eligible'] = False
    else:
        result['is_eligible'] = True

    return result


def determine_asset_limit_eligibility(state_data, assistance_unit):
    asset_test = get_best_rule(state_data, 'asset_test', assistance_unit)
    result = {}

    if "unrestricted_asset_limit" in asset_test:
        result['asset_limit'] = asset_test["unrestricted_asset_limit"]
        result['is_eligible'] = assistance_unit['assets']['cash'] < asset_test["unrestricted_asset_limit"]
    else:
        result['is_eligible'] = True

    return result


class Child:
    def __init__(self, birthdate):
        self.birthdate = birthdate

    def get_birthdate(self):
        return parse(self.birthdate)


class Adult:
    def __init__(self, earned_income=0, unearned_income=0, assets_cash=0, ssi=0):
        self.income = {
            'earned_income': earned_income,
            'unearned_income': unearned_income,
            'ssi': ssi
        }
        self.assets = {
            'cash': assets_cash
        }

    def get_income(self):
        return self.income

    def get_income_amount(self, income_type):
        return self.income[income_type]

    def get_assets(self):
        return self.assets

        # {
        #      'relationship': 'parent', # grandparent, stepparent, unrelated ?
        #      'birth_year': 1997,
        #      'income': {  # allows for different types of income...
        #        'earned_income': 0,  # TODO: monthly amounts?
        #        'unearned_income': 0,
        #      },
        #      'assets': {
        #        'cash': amount
        #      }
        #    },


# TODO: inputs(tanf_history_summary)
# how are we using assistance_history and what does it contain?
def calculate_cash_benefits(state, real_dollar_year, family, calculation_year, assistance_history=None):
    adults = []
    children = []

    for adult in family['adults']:
        earned_income = 0
        unearned_income = 0
        ssi = 0
        assets_cash = 0
        if 'income' in adult:
            if 'earned_income' in adult['income']:
                earned_income = adult['income']['earned_income']

            if 'unearned_income' in adult['income']:
                unearned_income = adult['income']['unearned_income']

            if 'ssi' in adult['income']:
                ssi = adult['income']['ssi']

        if 'assets' in adult:
            if 'cash' in adult['assets']:
                assets_cash = adult['assets']['cash']

        adults.append(Adult(earned_income, unearned_income, assets_cash, ssi))

    for child in family['children']:
        children.append(Child(child['birthdate']))

    return calculate_cash_benefits_expanded(state, real_dollar_year, adults, children, calculation_year,
                                            assistance_history=assistance_history)


def calculate_cash_benefits_expanded(state, real_dollar_year, adults, children, calculation_year,
                                     assistance_history=None):
    family = {
        'adults': adults,
        'children': children
    }
    # print(family)
    # TODO: inflate amount to year?
    # relationships between people?
    state_data = STATE_REFERENCE_PARAMETERS[state]

    # new_history = [] if assistance_history is None else list(assistance_history['history'])
    new_history = [] if assistance_history is None else list(assistance_history)

    annual_cash_benefit = 0
    result = []
    for i in range(0, 12):
        # m = i + 1
        # print(f"Month {m}")
        calculation_month = i + 1
        assistance_unit = determine_assistance_unit(state_data, state, real_dollar_year, family, calculation_year,
                                                    calculation_month, new_history)
        time_limit = determine_time_limit_compliance(state_data, state, real_dollar_year, family, assistance_unit,
                                                     calculation_year, calculation_month, new_history)
        if 'assistance_unit' in time_limit:
            assistance_unit = time_limit['assistance_unit']

        # TODO: we can also include pregnant women
        eligibility_of_two_parent_families = determine_eligibility_of_two_parent_families(state_data, assistance_unit)
        eligibility = determine_income_eligibility(state_data, assistance_unit, new_history)
        asset_eligibility = determine_asset_limit_eligibility(state_data, assistance_unit)

        if assistance_unit['child_count'] > 0 and eligibility_of_two_parent_families['is_eligible'] and eligibility[
            'is_eligible'] and time_limit['is_eligible'] and asset_eligibility['is_eligible']:
            benefits = determine_benefits(state_data, assistance_unit, new_history)
        else:
            benefits = {
                'cash_benefit': 0.0,
                'technically_eligible': False,
                'income_disregards': {}
            }

        annual_cash_benefit = annual_cash_benefit + benefits['cash_benefit']

        month_summary = {
            'assistance_unit': assistance_unit,
            'benefits': benefits,
            'eligibility': eligibility,
            'time_limit': time_limit,
            'asset_test': asset_eligibility
        }
        result.append(month_summary)
        new_history.append(month_summary)

    return {
        'annual_cash_benefit': annual_cash_benefit,
        'monthly_calculations': result,
        'history': new_history
    }


# 'REAL DOLLAR YEAR' is the year of the data source where the calculation refers to.
REAL_DOLLAR_YEAR = 2018


def initialize_calculate_store(args):
    # TODO: REFACTOR FOR A BETTER WAY TO INITIALIZE
    if "testing" not in args:
        initialize()
    try:
        if 'state_id' in args:
            args['state'] = STATE_ID_TO_ABBREVIATION[args['state_id']]
        # length of income list illustrate adults in household
        num_adults = len(args["earned_income_list"])
        # check all income list have same length
        if any(len(args_lst) != num_adults for args_lst in
               [args["unearned_income_list"], args["asset_cash_list"], args["ssi_income_list"]]):
            raise Exception(f"{args_lst} list length does not match the length of the other list.")
        family = {"adults": [], "children": []}
        for i in range(num_adults):
            adult = {"income": {}, "assets": {}}
            # get income value for this adult
            adult["income"]["earned_income"] = args["earned_income_list"][i]
            adult["income"]["unearned_income"] = args["unearned_income_list"][i]
            adult["income"]["ssi"] = args["ssi_income_list"][i]
            adult["assets"]["cash"] = args["asset_cash_list"][i]
            family["adults"].append(adult)
        for i in range(len(args["child_dob_list"])):
            date = julian_date_to_date(args["child_dob_list"][i])
            family["children"].append({"birthdate": date.isoformat(), "income": []})
        tanf_results = calculate_cash_benefits(args['state'], REAL_DOLLAR_YEAR, family, args['current_year'])
        args['annual_cash_benefit'] = np.array([tanf_results['annual_cash_benefit']])
    except Exception as e:
        logger.exception(f"exception: {e}", exc_info=True)
        raise e

    # return
    # - who is in the unit
    # - how much money they get
    # - for how many months
    # - ufff...could they be broken into separate units? - eg, exceed adult time limits, but kids still get aid
    # - could be that they are eligible for transitional assistance if they earn too much

    # ? are timelimits per FAMILY? per ASSISTANCE-UNIT? Are they attached to the adult in the family? What happens if
    #

#
# def main(args=None):
#     parser = argparse.ArgumentParser(description=__doc__, add_help=True)
#
#     parser.add_argument("--tanf_parameter_file", required=True)
#     parser.add_argument("--state", required=True)
#     parser.add_argument("--household_size", required=True, type=int)
#     parser.add_argument("--earned_income", required=True, type=float)
#     parser.add_argument("--childcare_cost", required=True, type=float)
#     parser.add_argument("--child_ages", nargs='+', required=True)
#
#     parser.add_argument("--parttime_age", help="Age when a child starts parttime care", required=True, type=int)
#
#     args = parser.parse_args(args)
#
#     initialize(args.ccdf_parameter_file)
#
#     child_ages = list(map(lambda x: int(x), args.child_ages))
#     eligible_children = filter_eligible(args.state, earned_income=args.earned_income, household_size=args.household_size, child_ages=child_ages, fulltime_age=args.parttime_age)
#
#     result = {
#         "eligible_children_ages": eligible_children
#     }
#     if len(eligible_children) > 0:
#         calculated_copay = calculate_copay(args.state, earned_income=args.earned_income, household_size=args.household_size, child_ages=eligible_children, childcare_cost=args.childcare_cost)
#         result['annual_copay'] = calculated_copay
#
#     # print(result)
#     print(json.dumps(result, sort_keys=True, indent=4))
#
#
#
# if __name__ == '__main__':
#     main()
