from box import Box
from enum import Enum
from us_benefits_calculator import get_full_path
from us_benefits_calculator.taxes.form_dependent import Form
from us_benefits_calculator.utils import STATE_ID_TO_ABBREVIATION
import logging
import math
import numpy as np

logger = logging.getLogger(__name__)


class Fields(Enum):
    """
    Fields are used as keys in the Form object and are helpful to keep name labeling consistent
    """
    SUM_OF_INFANTS_MONTHLY_BENEFIT = "sum of infants monthly benefit"
    SUM_OF_CHILDREN_MONTHLY_BENEFIT = "sum of children monthly benefit"
    MOTHER_MONTHLY_BENEFIT = "mother monthly benefit"
    NUM_OF_ELIGIBLE_INFANTS = "num of eligible infants"
    NUM_OF_ELIGIBLE_CHILDREN = "num of eligible children"
    ELIGIBLE_MOTHER = "eligible mother"
    TOTAL_MONTHLY_WIC_BENEFIT = "monthly_wic_benefit"
    MAX_ALLOWABLE_INCOME = "max allowable income"
    NO_DEPENDENTS = "no dependents"


class Wic:
    """
    WIC
    Special Supplemental Nutrition Program for Women, Infants, and Children (WIC)

    Assumptions

    - No dependents, no benefits
    - An unborn child is considered an addition to the household size and a dependent at the age of 0
    - If a household is categorically eligible , women may receive benefits:
      - Enrolled in Tanf, Snap, and/or Medicaid
      - Pregnant and/or infant
    - If a household is income eligible, women may receive benefits:
      - Pregnant and/or infant
    - A household may or may not have a mother, in which case, only the infant/child are credit
    """

    # ---Constructor---
    def __init__(self, parameters=None):
        if parameters is None:
            self.parameters = Box.from_yaml(filename = get_full_path('wic.yml'))
        else:
            self.parameters = parameters

    # ========================
    # Categorical Eligibility
    # ========================
    def is_categorically_eligible(self, children_accept_medicaid, adult_accept_medicaid, household_accept_tanf,
                                  household_accept_snap):
        """
        Check household enrollment in 'any' of the other benefit programs

        :param children_accept_medicaid: bool
        :param adult_accept_medicaid: bool
        :param household_accept_tanf: bool
        :param household_accept_snap: bool
        :return: bool
        """
        return any([children_accept_medicaid, adult_accept_medicaid, household_accept_tanf, household_accept_snap])

    def num_of_infants_and_children_eligible_by_age(self, dependents_ages):
        """
        Checks dependents' eligibility by age. If eligible, determine dependent as infant or child.

        :param dependents_ages: List[int]
        :return: (int, int)
        """
        num_infants = 0
        num_children = 0
        # infant age limit
        infant_lower_limit_age = self.parameters.eligibility.infant_age_limit.min_age_limit
        infant_upper_limit_age = self.parameters.eligibility.infant_age_limit.max_age_limit
        # child age limit
        child_min_age_limit = self.parameters.eligibility.child_age_limit.min_age_limit
        child_max_age_limit = self.parameters.eligibility.child_age_limit.max_age_limit
        for i in range(len(dependents_ages)):
            # check infant eligibility between ages 0 (inclusive) and 1 (exclusive)
            if infant_lower_limit_age <= dependents_ages[i] < infant_upper_limit_age:
                num_infants += 1
            # check children eligibility between ages 1(inclusive) and 5 (exclusive)
            elif child_min_age_limit <= dependents_ages[i] < child_max_age_limit:
                num_children += 1
        return num_infants, num_children

    # ===================
    # Income Eligibility
    # ===================
    def is_income_eligible(self, annual_income, household_size, state_abbreviation, form=None):
        """
        Checks household income eligibility by the state the family resides and household size

        :param annual_income: float
        :param household_size: int
        :param state_abbreviation: str
        :param form: Form
        :return: bool
        """
        # default base and increment amount
        base_amount = self.parameters.federal_poverty_level.states_income_eligibility.other.base_amount
        increment_amount = self.parameters.federal_poverty_level.states_income_eligibility.other.increment
        # however, if state is alaska or hawaii then change base and increment amount to the corresponding state
        if state_abbreviation in self.parameters.federal_poverty_level.states_income_eligibility:
            base_amount = self.parameters.federal_poverty_level.states_income_eligibility[
                state_abbreviation].base_amount
            increment_amount = self.parameters.federal_poverty_level.states_income_eligibility[
                state_abbreviation].increment
        # maximum income limit
        maximum_income_limit = self.maximum_allowable_income(base_amount, increment_amount, household_size, form)
        # check income eligibility
        return annual_income <= maximum_income_limit

    # ================
    # Helper Function
    # ================
    def maximum_allowable_income(self, base_amount, increment_amount, household_size, form=None):
        """
        Calculates the maximum allowable income based on the household size and state the family reside

        :param base_amount: float
        :param increment_amount: float
        :param household_size: int
        :param form: Form
        :return: float
        """
        total_increment_amount = increment_amount * (household_size - 1)
        max_limit = self.parameters.federal_poverty_level.multiplier * (base_amount + total_increment_amount)
        if form is not None:  # store results
            form.line(Fields.MAX_ALLOWABLE_INCOME.value, max_limit)
        return math.ceil(max_limit)

    def total_wic_value(self, num_of_infants, num_of_children, eligible_mother, form=None):
        """
        Calculates the total WIC value

        :param num_of_infants: int
        :param num_of_children: int
        :param eligible_mother: int
        :param form: Form
        :return: float
        """
        infant_monthly_benefit_sum = num_of_infants * self.parameters.monthly_benefit_value.infant
        children_monthly_benefit_sum = num_of_children * self.parameters.monthly_benefit_value.child
        mother_monthly_benefit_sum = eligible_mother * self.parameters.monthly_benefit_value.women
        if form is not None:  # store results
            form.line(Fields.SUM_OF_INFANTS_MONTHLY_BENEFIT.value, infant_monthly_benefit_sum)
            form.line(Fields.SUM_OF_CHILDREN_MONTHLY_BENEFIT.value, children_monthly_benefit_sum)
            form.line(Fields.MOTHER_MONTHLY_BENEFIT.value, mother_monthly_benefit_sum)
        return infant_monthly_benefit_sum + children_monthly_benefit_sum + mother_monthly_benefit_sum

    # ===========
    # Calculator
    # ===========
    def calculate_monthly_benefit(self, annual_income, dependents_ages, children_accept_medicaid, adult_accept_medicaid,
                                  household_accept_tanf, household_accept_snap, household_size, state_abbreviation,
                                  household_has_mother=True):
        """
        Determines the family's eligibility based on their income or categorical eligibility through receiving other
        benefits. If eligible, it calculates the WIC monthly benefit.

        :param annual_income: float
        :param dependents_ages: List[int]
        :param children_accept_medicaid: bool
        :param adult_accept_medicaid: bool
        :param household_accept_tanf: bool
        :param household_accept_snap: bool
        :param household_size: int
        :param household_has_mother: bool
        :param state_abbreviation: str
        :return: form.lines: dict
        """
        form = Form()
        # household enrollment on other benefits
        form.line("children accept medicaid", children_accept_medicaid)
        form.line("adult accept medicaid", adult_accept_medicaid)
        form.line("household accept tanf", household_accept_tanf)
        form.line("household accept snap", household_accept_snap)
        # initialize values
        eligible_mother = 0
        num_eligible_children = 0
        num_eligible_infants = 0
        total_monthly_wic_benefit = 0
        # base case for no dependents
        if len(dependents_ages) <= 0:
            form.line(Fields.NO_DEPENDENTS.value, len(dependents_ages))
            form.line(Fields.TOTAL_MONTHLY_WIC_BENEFIT.value, total_monthly_wic_benefit)
            return form.lines
        # check for income or categorical eligibility
        if self.is_income_eligible(annual_income, household_size, state_abbreviation, form) \
                or self.is_categorically_eligible(children_accept_medicaid, adult_accept_medicaid,
                                                  household_accept_tanf, household_accept_snap):
            num_eligible_infants, num_eligible_children = self.num_of_infants_and_children_eligible_by_age(
                dependents_ages)
            eligible_mother = 1 if num_eligible_infants > 0 and household_has_mother else 0
        form.line(Fields.NUM_OF_ELIGIBLE_INFANTS.value, num_eligible_infants)
        form.line(Fields.NUM_OF_ELIGIBLE_CHILDREN.value, num_eligible_children)
        form.line(Fields.ELIGIBLE_MOTHER.value, eligible_mother)
        # calculate wic
        total_monthly_wic_benefit = self.total_wic_value(num_eligible_infants, num_eligible_children, eligible_mother,
                                                         form)
        form.line(Fields.TOTAL_MONTHLY_WIC_BENEFIT.value, total_monthly_wic_benefit)
        return form.lines


WIC_CALC = None


def initialize_calculate_store(args):
    """
    This method is called from the computation engine to calculate WIC benefit

    :param args: Dict[str, Any]
    :return:
    """
    try:
        if "state_id" in args:
            args["state"] = STATE_ID_TO_ABBREVIATION[args["state_id"]]
        global WIC_CALC
        if WIC_CALC is None:
            WIC_CALC = Wic()
        total_monthly_wic_amt, form_outputs = WIC_CALC.calculate_monthly_benefit(args["annual_earned_income"],
                                                                                 args["child_ages"],
                                                                                 args["children_accept_medicaid"],
                                                                                 args["adult_accept_medicaid"],
                                                                                 args["household_accept_tanf"],
                                                                                 args["household_accept_snap"],
                                                                                 args["household_size"],
                                                                                 args["state"],
                                                                                 args["household_has_mother"])
        args["total_monthly_wic_benefit"] = np.array([total_monthly_wic_amt])
        args["total_annual_wic_benefit"] = np.array([round(total_monthly_wic_amt * 12, 2)])

    except Exception as e:
        logger.exception(f"exception: {e}", exc_info=True)
        raise e
