from enum import Enum


class BenefitNames(Enum):
    ACA = "ACA"
    CCDF = "CCDF"
    FED_CDCTC = "Fed_CDCTC"
    STATE_CDCTC = "State_CDCTC"
    SNAP = "SNAP"
    TANF = "TANF"
    WIC = "WIC"
