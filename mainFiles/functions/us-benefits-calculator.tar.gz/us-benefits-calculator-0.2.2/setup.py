from setuptools import setup, find_packages
import os
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# datadir = os.path.join('src','us_benefits_calculator', 'data')
# datafiles = [(d, [os.path.join(d,f) for f in files])
#              for d, folders, files in os.walk(datadir)]
#
# print(datafiles)
setup(
    name="us-benefits-calculator",
    version="0.2.2",
    author="Michael Leiseca",
    author_email="michael@economicsecurityplanning.com",
    description="Calculate US government transfer program benefits",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="http://com.esplanning.governmentbenefits.s3-website-us-east-1.amazonaws.com",
    packages=find_packages('src'),
    package_dir={'': 'src'},
    package_data={
        '': ['data/*']
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.5',
    install_requires=[
        'python-dateutil ~= 2.8.1',
        'numpy >= 1.19.0'
    ],
    extras_require={
    },
    setup_requires=[
    ],
    zip_safe=False,
)
