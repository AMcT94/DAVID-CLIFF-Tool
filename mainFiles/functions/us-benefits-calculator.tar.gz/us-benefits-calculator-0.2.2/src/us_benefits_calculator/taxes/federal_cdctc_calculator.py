import json
import numpy as np
from us_benefits_calculator import get_full_path
from us_benefits_calculator.taxes.form_dependent import Form, Dependent
import logging

logger = logging.getLogger(__name__)
"""Federal-Level

Child and Dependent Care Tax Credit (cdctc)
Calculations are based on the Form 2441
"""

class FederalCdctcCalculator:
    def __init__(self, parameters=None):
        if parameters is None:
            with open(get_full_path('federal_cdctc_form_2441.json')) as parameters_file:
                self.parameters = json.load(parameters_file)
        else:
            self.parameters = parameters

    def maximum_qualified_expense(self, number_of_dependents):
        expenses_by_number = self.parameters["qualified_maximum_expenses"]
        return expenses_by_number[str(min(number_of_dependents, len(expenses_by_number.keys())))]

    def filter_qualified_dependents(self, dependents):
        qualified_dependents = []
        for d in dependents:
            if d.age() <= self.parameters["qualifying_child_maximum_age"]:
                qualified_dependents.append(d)
        return qualified_dependents

    def calculate(self, dependents, earned_income, spouse_earned_income, adjusted_gross_income, total_tax, foreign_tax):
        """
        Assume that there are no dependent care benefits.
        Dependent care benefits include:
            • Amounts your employer paid directly to either you or
            your care provider for the care of your qualifying person(s)
            while you worked,
            • The fair market value of care in a daycare facility
            provided or sponsored by your employer, and
            • Pre-tax contributions you made under a dependent
            care flexible spending arrangement (FSA).

        A qualifying person is:
            1. A qualifying child under age 13 whom you can claim
            as a dependent. If the child turned 13 during the year, the
            child is a qualifying person for the part of the year he or
            she was under age 13;
            2. Your disabled spouse who wasn't physically or
            mentally able to care for himself or herself;
            3. Any disabled person who wasn't physically or
            mentally able to care for himself or herself whom you can
            claim as a dependent or could claim as a dependent
            except:
            a. The disabled person had gross income of $4,300 or
            more,
            b. The disabled person filed a joint return, or
            c. You (or your spouse if filing jointly) could be claimed
            as a dependent on another taxpayer's 2020 return.
            If you are divorced or separated, see Special rule for
            children of divorced or separated parents or parents who
            live apart below.
        :return:
        """
        form = Form()
        qualified_dependents = self.filter_qualified_dependents(dependents)

        # 3 Add the amounts in column (c) of line 2. Don’t enter more than $3,000 for one qualifying person
        # or $6,000 for two or more persons. If you completed Part III, enter the amount from line 31
        total_expenses = 0
        form.line(3, min(sum(d.cost_of_care() for d in qualified_dependents),
                         self.maximum_qualified_expense(len(qualified_dependents))))

        # 4 Enter your earned income. See instructions
        form.line(4, earned_income)

        # 5 If married filing jointly, enter your spouse’s earned income (if you or your spouse was a student
        # or was disabled, see the instructions); all others, enter the amount from line 4
        # TODO: complicated logic
        # TODO: This is going to be broken - we need to pass filing status. Can't put $0 or line 6 will always be $0
        form.line(5, spouse_earned_income)

        # 6 Enter the smallest of line 3, 4, or 5
        form.line(6, form.smallest_of_lines(form.lines, 3, 4, 5))

        # 7 Enter the amount from Form 1040, 1040-SR, or 1040-NR, line 11
        form.line(7, adjusted_gross_income)

        # 8  Enter on line 8 the decimal amount shown below that applies to the amount on line 7.
        form.line(8, form.lookup_decimal_amount(self.parameters['federal_agi_decimal_bracket'], form.lines[7]))

        # 9 Multiply line 6 by the decimal amount on line 8. If you paid 2019 expenses in 2020, see the
        # instructions
        # NOTE: This does not take into assumption if you paid 2019 expenses in 2020
        form.line(9, form.lines[6] * form.lines[8])

        # 10 Tax liability limit. Enter the amount from the Credit Limit Worksheet
        # in the instructions
        form.line(10, form.tax_libiality_amt_form_2441(total_tax, foreign_tax))

        # 11 Credit for child and dependent care expenses. Enter the smaller of line 9 or line 10 here and
        # on Schedule 3 (Form 1040), line 2
        form.line(11, form.smallest_of_lines(form.lines, 9, 10))
        return form.line(11), form


FEDERAL_CALCULATOR = None

def initialize_calculate_store(args):
    try:
        global FEDERAL_CALCULATOR
        
        if FEDERAL_CALCULATOR is None:
            FEDERAL_CALCULATOR = FederalCdctcCalculator()    
        
        if len(args["child_ages"]) != len(args["childcare_expenses"]):
            raise Exception(f"child_ages doesn't match childcare_expenses: {args['child_ages']} vs {args['childcare_expenses']}")

        dependents = []
        for i in range(0, len(args["child_ages"])):
            dependents.append(Dependent(args["child_ages"][i], args["childcare_expenses"][i]))

        # It would be nicer if we could pass in the filing status. We are getting around that by copying the earned_income
        # to spouse earned income.
        if "spouse_earned_income" in args:
            spouse_earned_income = args["spouse_earned_income"]
        else:
            spouse_earned_income = args["earned_income"]

        credit_amount, form_outputs = FEDERAL_CALCULATOR.calculate(dependents, args["earned_income"], spouse_earned_income, args["federal_agi"], args["total_tax"], args["foreign_tax"])

        args['Form2441Line9'] = np.array([form_outputs.line(9)])
        args['Form2441Line11'] = np.array([form_outputs.line(11)])

        # logger.info(f"federal CDCTC args: {args}")
    except Exception as e:
        logger.exception(f"exception: {e}", exc_info=True)
        raise e