"""
Helper class for Federal and State CDCTC
"""
class Dependent:
    def __init__(self, age, cost_of_care):
        self.age_ = age
        self.cost_of_care_ = cost_of_care

    def age(self):
        return self.age_

    def cost_of_care(self):
        return self.cost_of_care_

class Form:
    def __init__(self):
        self.lines = {}

    def line(self, number, value=None):
        if value is None:
            return self.lines[number]
        else:
            self.lines[number] = value

    def smallest_of_lines(self, form_lines_dict, *args):
        sliced_dict = {key: form_lines_dict[key] for key in form_lines_dict.keys() & {*args}}
        return min(sliced_dict.values())

    def lookup_decimal_amount(self, bracket_name, value):
        if type(bracket_name) is not list:
            return float(bracket_name)
        for i in bracket_name:
            if "limit" not in i or value <= i["limit"]:
                return i["decimal"]
                break
            else:
                continue

    def tax_libiality_amt_form_2441(self, total_tax, foreign_tax):
        # foreign_tax comes from SCHEDULE 3 FORM 1040 LINE 1
        # total_tax comes from FORM 1040, 1040-SR, 1040-NR line 18
        # This form instructs to subtract foreign_tax from total_tax, if zero of less, you cannot take the credit
        difference = total_tax - foreign_tax
        return difference if difference > 0 else 0
