import os

# https://stackoverflow.com/questions/4519127/setuptools-package-data-folder-location
_ROOT = os.path.abspath(os.path.dirname(__file__))

def get_full_path(path):
    return os.path.join(_ROOT, 'data', path)

