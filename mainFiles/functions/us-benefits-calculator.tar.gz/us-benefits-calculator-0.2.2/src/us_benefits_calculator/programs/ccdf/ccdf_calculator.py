import argparse
import json
import logging
import numpy as np
import re
from us_benefits_calculator import get_full_path
from us_benefits_calculator.utils import get_poverty_level, STATE_ID_TO_ABBREVIATION

logger = logging.getLogger(__name__)

STATE_REFERENCE_PARAMETERS = None

state_name_mapping = {
    'Alabama': 'AL',
    'Alaska': 'AK',
    'Arizona': 'AZ',
    'Arkansas': 'AR',
    'California': 'CA',
    'Colorado': 'CO',
    'Connecticut': 'CT',
    'Delaware': 'DE',
    'District of Columbia': 'DC',
    'DC': 'DC',
    'Florida': 'FL',
    'Georgia': 'GA',
    'Hawaii': 'HI',
    'Idaho': 'ID',
    'Illinois': 'IL',
    'Indiana': 'IN',
    'Iowa': 'IA',
    'Kansas': 'KS',
    'Kentucky': 'KY',
    'Louisiana': 'LA',
    'Maine': 'ME',
    'Maryland': 'MD',
    'Massachusetts': 'MA',
    'Michigan': 'MI',
    'Minnesota': 'MN',
    'Mississippi': 'MS',
    'Missouri': 'MO',
    'Montana': 'MT',
    'Nebraska': 'NE',
    'Nevada': 'NV',
    'New Hampshire': 'NH',
    'New Jersey': 'NJ',
    'New Mexico': 'NM',
    'New York': 'NY',
    'North Carolina': 'NC',
    'North Dakota': 'ND',
    'Ohio': 'OH',
    'Oklahoma': 'OK',
    'Oregon': 'OR',
    'Pennsylvania': 'PA',
    'Rhode Island': 'RI',
    'South Carolina': 'SC',
    'South Dakota': 'SD',
    'Tennessee': 'TN',
    'Texas': 'TX',
    'Utah': 'UT',
    'Vermont': 'VT',
    'Virginia': 'VA',
    'Washington': 'WA',
    'West Virginia': 'WV',
    'Wisconsin': 'WI',
    'Wyoming': 'WY',
}

child_count_by_type = {
    'children_in_care_1': 1,
    'children_in_care_2': 2,
    'children_in_care_3': 3,
    'children_in_care_1_under_2': 1,
    'children_in_care_2_under_2_and_older': 2,
    'children_in_care_3_under_2_and_older': 3,
    'children_in_care_1_older_than_2': 1,
    'children_in_care_2_older_than_2': 2,
    'children_in_care_3_older_than_2': 3,
    'children_in_care_2_under_2': 2,
    'children_in_care_3_under_2': 3,
    'children_in_care_3_with_2_under_2': 3,
}

child_under_2_count_by_type = {
    'children_in_care_1_under_2': 1,
    'children_in_care_2_under_2_and_older': 1,
    'children_in_care_3_under_2_and_older': 1,
    'children_in_care_1_older_than_2': 0,
    'children_in_care_2_older_than_2': 0,
    'children_in_care_3_older_than_2': 0,
    'children_in_care_2_under_2': 2,
    'children_in_care_3_under_2': 3,
    'children_in_care_3_with_2_under_2': 2,
}


def parse(v):
    if v == "-1":
        return None
    else:
        return int(v.replace(',', ''))


def load_test_data(filename, field_count):
    result = {}
    with open(filename) as f:
        lines = f.readlines()
        columns = lines[0].rstrip().split(',')

        for i in range(1, len(lines)):
            s = lines[i].rstrip().replace('Not eligible', '-1')
            if s.startswith('#'):
                continue

            placeholders = []
            for _ in range(field_count):
                placeholders.append("(-?[\\d,]+)")

            # NOTE: Some states still have footnote! There might be an extra number right after the state name. This
            #  number should be ignored
            pattern = f"(.*?)(?: \\d+ )?{' '.join(placeholders)}$"
            prog = re.compile(pattern)
            m = re.match(prog, s)
            if not m:
                raise ValueError(f"Problem parsing line: {s}")
            state = m.group(1).rstrip()
            if state not in state_name_mapping:
                # print(f"SKIPPING '{state}'")
                continue
            result[state_name_mapping[state]] = {}
            for j in range(field_count):
                result[state_name_mapping[state]][columns[j + 1]] = parse(m.group(j + 2))

    return result


def determine_copay_group(state_data, fulltime_ages, parttime_ages):
    """
    There are different grouping of copay groups based on the state
    - all - for all families
    - full_time_care vs part_time_care
    - copays based on the family size and number of children in care

    This function assumes that the state has a single copay group which matches the family
    """
    all_ages = fulltime_ages + parttime_ages
    total_children = len(all_ages)
    ages_under_2 = sum(1 for age in all_ages if age < 2)

    copays_by_group = state_data['copays']['by_group']

    # If a state has an 'all' group, we use that
    if "all" in copays_by_group:
        return copays_by_group['all']

    # Some states divide by care group - if anyone is in full time, they get full time copays
    if 'full_time_care' in copays_by_group:
        if len(fulltime_ages) > 0:
            return copays_by_group['full_time_care']
        else:
            return copays_by_group['part_time_care']

    # The remaining copay groups are distinguished by the number of children in care.
    total_children_groups = match_group_by_child_count(total_children, copays_by_group, child_count_by_type)

    # Some states have a single group based on the number of children
    if len(total_children_groups.values()) == 1:
        return list(total_children_groups.values())[0]

    # ...however, MD does something special. There are multiple groups for a number of children. For example,
    #     'children_in_care_1_under_2' and 'children_in_care_1_older_than_2' are both for 1 child.
    #  children_in_care_1_under_2 is if the child is under 2
    #  children_in_care_1_older_than_2 is if the child is 2 or older
    young_child_groups = match_group_by_child_count(ages_under_2, total_children_groups,
                                                    child_under_2_count_by_type)
    if len(young_child_groups) == 1:
        return list(young_child_groups.values())[0]

    # This represents a configuration error and shouldn't happen
    raise ValueError(
        f"No family group for total {total_children} and {ages_under_2}. Found: {young_child_groups.keys()}")


def match_group_by_child_count(total_children, copays_by_group, child_count_map):
    """
    Utility function to match the number of children to the copay group
    """
    max_child_group_size = 0
    total_children_groups = {}
    for group in copays_by_group:
        max_child_group_size = max(max_child_group_size, child_count_map[group])

    for group in copays_by_group:
        if total_children == child_count_map[group] or \
                (total_children > max_child_group_size and child_count_map[group] == max_child_group_size):
            total_children_groups[group] = copays_by_group[group]

    return total_children_groups


def lookup_reference_amount_and_index(state, income, household_size, child_ages, fulltime_age):
    """
    Based on the family income, size, and number of children, determine the reference amount and index of the reference
    amount

    :return: tuple of reference amount and reference index
    """
    state_data = STATE_REFERENCE_PARAMETERS[state]

    child_ages = filter_max_age(state, child_ages)
    fulltime_ages, parttime_ages = separate_by_care_level(child_ages, fulltime_age)

    copay_group = determine_copay_group(state_data, fulltime_ages, parttime_ages)

    reference_index, state_family_size = get_reference_index_from_copay_group(copay_group, household_size, income)
    reference_index = min(reference_index, len(copay_group['copay_reference_amount'][state_family_size]) - 1)
    reference = copay_group['copay_reference_amount'][str(state_family_size)][reference_index]

    return reference, reference_index


def get_reference_index_from_copay_group(copay_group, household_size, income):
    state_family_size = min(household_size, copay_group['max_family_size_for_group'])
    if state_family_size == 0:
        raise ValueError(f"Unsupported family size {household_size}")
    income_limit = copay_group['income_limit'][str(state_family_size)]
    result = len(income_limit) - 1
    for i in range(len(income_limit)):
        # print(f"{income} vs {income_limit[i]}")
        if income < income_limit[i]:
            result = i
            break

    return result, str(state_family_size)


def calculate_with_multiple_groups(state, income, household_size, child_ages, fulltime_age):
    state_data = STATE_REFERENCE_PARAMETERS[state]
    groups = state_data['copays']['by_group']

    # Children must be below the state's max age
    child_ages = filter_max_age(state, child_ages)
    fulltime_ages, parttime_ages = separate_by_care_level(child_ages, fulltime_age)

    total_copay = 0

    full_time_kids = len(fulltime_ages)
    part_time_kids = len(parttime_ages)
    i = 0
    while full_time_kids > 0 or part_time_kids > 0:
        i = i + 1
        group_name = f"child_in_care_number_{i}"
        if group_name in groups:
            group = groups[group_name]

            reference_index, state_family_size = get_reference_index_from_copay_group(group, household_size, income)
            reference_index = min(reference_index, len(group['copay_reference_amount'][state_family_size]) - 1)
            reference = group['copay_reference_amount'][str(state_family_size)][reference_index]

            if state_data['copays']['calculation']['method'] == 'dollar_amount':
                base_copay = reference * state_data['copays']['calculation']['to_monthly_value_multiplier']
            else:
                raise ValueError("expected dollar amount method")

            if full_time_kids > 0:
                full_time_kids = full_time_kids - 1
                total_copay = total_copay + base_copay
            else:
                part_time_kids = part_time_kids - 1
                total_copay = total_copay + (base_copay * get_part_time_multiplier(state_data)[0])
        else:
            # No more groups. Time to stop
            break

    return int(total_copay * 12)


def get_part_time_multiplier(state_data):
    calculation = state_data['copays']['calculation']

    if calculation['before_after_adjustment']['type'] == 'adjusted' \
            and calculation['before_after_adjustment']['method'] != 'other':
        return calculation['before_after_adjustment']['amount'] / 100, calculation['before_after_adjustment']['method']

    if calculation['part_time_adjustment']['type'] == 'adjusted' \
            and calculation['part_time_adjustment']['method'] != 'other':
        return calculation['part_time_adjustment']['amount'] / 100, calculation['part_time_adjustment']['method']

    return 1, "na"


def calculate_percent_of_income_method(state_data, income, reference, reference_index, fulltime_ages, parttime_ages):
    base_copay = income * reference / 100

    multi_kid_method = state_data['copays']['calculation']['multiple_child_adjustment']['method']

    total_children = len(fulltime_ages) + len(parttime_ages)
    total_copay = 0
    if multi_kid_method == 'family_level_copay':
        total_copay = base_copay

    if multi_kid_method == 'dollar_amount':
        if total_children == 1:
            total_copay = base_copay
        else:
            adjustment = state_data['copays']['calculation']['multiple_child_adjustment'][str(min(total_children, 4))]
            amount = get_adjustment_amount(adjustment, reference_index)
            total_copay = base_copay + (12 * amount * total_children)

    return total_copay


def calculate_with_single(state, income, household_size, child_ages, fulltime_age, monthly_childcare_cost):
    state_data = STATE_REFERENCE_PARAMETERS[state]

    # Children must be below the state's max age
    child_ages = filter_max_age(state, child_ages)
    fulltime_ages, parttime_ages = separate_by_care_level(child_ages, fulltime_age)

    if 'method' in state_data['copays']['calculation']:
        reference, reference_index = lookup_reference_amount_and_index(state, income, household_size,
                                                                       child_ages, fulltime_age)
        method = state_data['copays']['calculation']['method']
        if method == 'dollar_amount':
            return calculate_dollar_amount_method(state_data, fulltime_ages, parttime_ages, reference, reference_index)

        if method == 'percent_of_childcare_cost':
            return 12 * monthly_childcare_cost * reference / 100

        if method == 'percent_of_income':
            return calculate_percent_of_income_method(state_data, income, reference, reference_index, fulltime_ages,
                                                      parttime_ages)

        raise ValueError(f"Unknown method: {method}")
    else:
        if state == 'HI':
            reference, reference_index = lookup_reference_amount_and_index(state, income, household_size,
                                                                           child_ages, fulltime_age)
            return 12 * monthly_childcare_cost * reference / 100
        elif state == 'OH':
            # Caseworkers use a desk guide to show families their expected copayment.
            # The state calculates the family's copayment by dividing the family's annual income by 100 percent of the Federal Poverty Guidelines.
            # The family's poverty level is then rounded up to the nearest five percent, multiplied by 100 percent of the Federal Poverty Guidelines, divided by twelve, and rounded up to the nearest whole number to get the maximum monthly income.
            # The maximum monthly income is then multiplied by a copayment multiplier that varies depending on the family's poverty level, rounded to the nearest whole dollar, multiplied by twelve, and divided by the number of weeks in the current state fiscal year to get the family's weekly copayment.
            #
            # I think Urban institute is overthinking this. THere's a copy of the desk reference in esp-scripts/tfa/ccdf.
            # It defines the weekly copay and matches the data Urban institute is publishing
            reference, reference_index = lookup_reference_amount_and_index(state, income, household_size,
                                                                           child_ages, fulltime_age)
            return 12 * reference * state_data['copays']['calculation']['to_monthly_value_multiplier']
        elif state == 'OR':
            # ! The Oregon base FPL for the family
            # xxx = or_fpl_base(MIN(householdSize, 8))
            # xxx = growAmount(xxx, data_year, growToYear, REAL_WAGE_GROWTH_RATE)
            poverty_level_2007 = get_poverty_level(2007, state, household_size)
            #
            # ! This is the base payment for the family ($27)
            base_payment = 12 * 27
            #
            # ! From http://apps.state.or.us/caf/arm/B/461-155-0150.htm
            # ! Section 5.e, 5.f.A, 5.f.B, and 12.b define the rest of the formula.
            # ! MAX(27, INCOME * ((MAX(0, (round(INCOME/2007_FPL, 2) - 0.5)) * 0.12) + 0.015) * 1.1)
            return max(base_payment,
                    income * ((max(0.0, (income/poverty_level_2007 - 0.5)) * 0.12) + 0.015) * 1.1)
        elif state == 'SD':
            # ! Households with income below 100 percent of the Federal Poverty Guidelines pay $0 monthly.
            # ! Households with income between 100 and 105 percent of the Federal Poverty Guidelines pay $5 monthly.
            # ! Households with income over 105 percent and up to and including 110 percent of the Federal Poverty Guidelines have a copayment of $10 monthly.
            # ! Households with income above 110 percent of the Federal Poverty Guidelines pay a copayment of 110 percent of the Federal Poverty Guideline subtracted from their income or 14 percent of their income, whichever is less.
            # ! Copayment amounts are rounded down to the closest whole dollar.
            #
            # ! I don't know where Urban gets that. There's a chart in esp-scripts/tfa/ccdf
            # TODO: new input for real dollar year
            percent_of_fpl = income / get_poverty_level(2018, state, household_size) * 100
            if percent_of_fpl <= 160:
                return 0
            else:
                sd_multiplier = [1, 7.2, 9.2, 11,  12.8, 14.8, 16.6, 18.4]
                return 12 * (percent_of_fpl - 160) * sd_multiplier[min(len(sd_multiplier), household_size) - 1]
        elif state == 'WA':
            # TODO: new input for real dollar year
            fpl = get_poverty_level(2018, state, household_size)
            percent_of_fpl = income / fpl * 100
            if percent_of_fpl <= 82:
                return 12 * 15
            elif percent_of_fpl < 137.5:
                return 12 * 65
            else:
                # Since we are dealing with the annual income, we don't multiple by 12
                return (min(income, 2.0 * fpl) - 1.375 * fpl) * 0.5 + (12 * 65.0)

        elif state == 'WI':
            # WI - The family copayment is calculated multiplying an hourly copayment amount (determined by the number of children in care) by the total number of hours of subsidized care for all children in the household.
            # Families with five or more children in care pay the same copayment, regardless of the number of additional children in care.
            # TODO: new input for real dollar year
            percent_of_fpl = income / get_poverty_level(2018, state, household_size) * 100
            percent_of_fpl = max(65, percent_of_fpl)
            bounded_child_count = min(5, max(1, len(child_ages)))
            if bounded_child_count == 1:
                hourly_rate = -0.955455 + 0.0168182 * percent_of_fpl
            elif bounded_child_count == 2:
                hourly_rate = -0.531818 + 0.0102727 * percent_of_fpl
            elif bounded_child_count == 3:
                hourly_rate = -0.365455 + 0.00781818 * percent_of_fpl
            elif bounded_child_count == 4:
                hourly_rate = -0.266364 + 0.00645455 * percent_of_fpl
            else:
                hourly_rate = -0.210909 + 0.00563636 * percent_of_fpl

            fulltime_rate = 152 # number of hours for full time care
            return (len(fulltime_ages) * fulltime_rate + len(parttime_ages) * fulltime_rate / 2) * hourly_rate * 12
        else:
            raise ValueError(f"Unsupported state calculation: {state}")


def get_adjustment_amount(discount, reference_index):
    if 'amount' in discount:
        if isinstance(discount['amount'], list):
            amount = float(discount['amount'][reference_index])
        else:
            try:
                amount = float(discount['amount'])
            except ValueError:
                # not an int....
                amount = None
    else:
        amount = None

    if discount['type'] == 'na':
        result = 0
    elif discount['type'] == 'percent_of_one_child_copay':
        result = amount / 100
    elif discount['type'] in ['copay_addition', 'dollar_amount_addition']:
        result = amount
    else:
        raise ValueError(f"Unhandled multi kid discount logic: {discount}")

    return result


def calculate_dollar_amount_method(state_data, fulltime_ages, parttime_ages, reference, reference_index):
    base_copay = reference * state_data['copays']['calculation']['to_monthly_value_multiplier']

    full_time_kids = len(fulltime_ages)
    part_time_kids = len(parttime_ages)
    total_children = full_time_kids + part_time_kids

    monthly_copay = 0
    part_time_multiplier = get_part_time_multiplier(state_data)[0]
    multi_kid_method = state_data['copays']['calculation']['multiple_child_adjustment']['method']

    if multi_kid_method == 'child_level_copay':
        monthly_copay = (base_copay * full_time_kids) + (base_copay * part_time_multiplier * part_time_kids)

    if multi_kid_method in ['percent_of_base', 'percent_of_full_time_copay']:

        kid_index = 0  # multiple_child_adjustment index
        while full_time_kids > 0 or part_time_kids > 0:
            kid_index = kid_index + 1  # Starts with 1
            if full_time_kids > 0:
                full_time_kids = full_time_kids - 1
                part_time_multiplier = 1
                is_part_time = False
            else:
                part_time_kids = part_time_kids - 1
                part_time_multiplier = get_part_time_multiplier(state_data)[0]
                is_part_time = True

            if kid_index == 1:  # first kid is full price
                monthly_copay = monthly_copay + (base_copay * part_time_multiplier)
            else:
                # There are only up to 4 discounts
                discount = state_data['copays']['calculation']['multiple_child_adjustment'][str(min(kid_index, 4))]
                if multi_kid_method == 'percent_of_full_time_copay' and is_part_time:
                    # if the state is percent_of_full_time_copay, they give either the part time or multi kid discount
                    multi_kid_multiplier = 1
                    part_time_multiplier = min(part_time_multiplier, int(discount['amount']) / 100)
                else:
                    multi_kid_multiplier = get_adjustment_amount(discount, reference_index)

                monthly_copay = monthly_copay + (base_copay * part_time_multiplier * multi_kid_multiplier)

    if multi_kid_method in ['copay_schedule', 'family_level_copay']:
        # The copay schedule is already scaling to multiple children for us. No need to multiply
        monthly_copay = base_copay

    if multi_kid_method == 'most_attending_child_multiplier':
        if total_children == 1:
            additional_copay = 0
        else:
            discount = state_data['copays']['calculation']['multiple_child_adjustment'][str(min(total_children, 4))]
            additional_copay = get_adjustment_amount(discount, reference_index)

        if full_time_kids == 0:
            part_time_multiplier = get_part_time_multiplier(state_data)[0]
        else:
            part_time_multiplier = 1

        monthly_copay = base_copay + (
                state_data['copays']['calculation']['to_monthly_value_multiplier'] * additional_copay)
        monthly_copay = monthly_copay * part_time_multiplier

    return int(monthly_copay * 12)


POVERTY = {
    2007: {
        "other": {"base": 10210, "extra": 3480},
    },

    2017: {
        "other": {"base": 12060, "extra": 4180},
        "AK":    {"base": 15060, "extra": 5230},
        "HI":    {"base": 13860, "extra": 4810}
    },
    2018: {
        "other": {"base": 12140, "extra": 4320},
        "AK":    {"base": 15180, "extra": 5400},
        "HI":    {"base": 13960, "extra": 4810},
    },
    2019: {
        "other": {"base": 12490, "extra": 4420},
        "AK":    {"base": 15600, "extra": 5530},
        "HI":    {"base": 14380, "extra": 5080},
    }
}


def is_exempt(state, earned_income, household_size, tanf_recipient, ssi_recipient):
    state_data = STATE_REFERENCE_PARAMETERS[state]

    exemptions = state_data['copays']['exemptions']

    if 'poverty' in exemptions:
        assert exemptions['poverty']['type'] == 'fpl', 'Only know how to process FPL poverty leve'

        if earned_income < get_poverty_level(exemptions['poverty']['year'], state, household_size):
            return True

    if 'ssi' in exemptions and ssi_recipient:
        return True

    if 'tanf' in exemptions and tanf_recipient:
        if earned_income == 0 and 'no_earned_income' in exemptions['tanf']:
            return True

        if earned_income > 0 and 'earned_income' in exemptions['tanf']:
            return True

    return False


def calculate_copay(state, earned_income=0, household_size=0, child_ages=[], monthly_childcare_cost=0, fulltime_age=5,
                    tanf_recipient=False, ssi_recipient=False):

    state_data = STATE_REFERENCE_PARAMETERS[state]

    income = earned_income

    # Children must be below the state's max age - if not, throw an exception
    child_ages_below_max = filter_max_age(state, child_ages)
    assert child_ages_below_max == child_ages

    # Check is family is exempt from copay
    if is_exempt(state, earned_income, household_size, tanf_recipient, ssi_recipient):
        return 0

    if 'child_in_care_number_1' in state_data['copays']['by_group']:
        result = calculate_with_multiple_groups(state, income, household_size, child_ages, fulltime_age)
    else:
        result = calculate_with_single(state, income, household_size, child_ages, fulltime_age, monthly_childcare_cost)

    calculation = state_data['copays']['calculation']
    if 'minimum' in calculation:
        # The state has a 'minimum' copay, so we need to make sure that result exceeds the minimum
        minimum_logic = calculation['minimum']

        if minimum_logic['method'] == 'dollar_amount':
            minimum_copay = minimum_logic['amount'] * minimum_logic['to_monthly_value_multiplier'] * 12
        elif minimum_logic['method'] == 'percent_of_cost':
            minimum_copay = minimum_logic['amount'] / 100 * monthly_childcare_cost * 12
        else:
            # There are no other methods, so we should throw an error
            raise ValueError(f"Unexpected minimum_logic: {minimum_logic}")

        result = max(result, minimum_copay)

    return round(result, 2)


def determine_eligibility_group(state_data, tanf_recipient, fulltime_ages, parttime_ages):
    """
    Match the household to one of the eligibility groups for the state.
    """

    # Simple case: there is an 'all' group for the state.
    if 'all' in state_data['eligibility']['thresholds']:
        return state_data['eligibility']['thresholds']['all']

    # There are groups specific to the family situation. We either match the family or return the 'other' group
    for name, group in state_data['eligibility']['thresholds'].items():
        if name == 'tanf' and tanf_recipient:
            return group
        if name == 'full_time_care' and len(fulltime_ages) > 0:
            return group
        if name == 'part_time_care' and len(fulltime_ages) == 0:
            return group

    # If the household doesn't match a specific group, we use the 'other' as fallback
    return state_data['eligibility']['thresholds']['other']


def lookup_eligibility_amount(state, household_size=0, tanf_recipient=False, fulltime_ages=[],
                              parttime_ages=[], continuing_eligibility=False):
    state_data = STATE_REFERENCE_PARAMETERS[state]
    eligibility_group = determine_eligibility_group(state_data, tanf_recipient, fulltime_ages,
                                                    parttime_ages)

    # There can be households larger than the number listed in the inital group
    # In that case, we just use the last vale
    # LIMITATION: Urban doesn't encode standards, they only encode the dollar amount. This means we miss large families.
    if continuing_eligibility:
        thresholds = eligibility_group['continuing']
    else:
        thresholds = eligibility_group['initial']

    eligibility_household_size = min(len(thresholds), household_size)
    return thresholds[eligibility_household_size - 1]


def separate_by_care_level(ages, fulltime_age):
    """
    Breaks the 'ages' list into two lists
     - list 0 is full time ages
     - list 1 is part time ages
    """
    result = ([], [])

    for age in ages:
        if age < fulltime_age:
            result[0].append(age)
        else:
            result[1].append(age)

    return result


def filter_max_age(state, ages):
    """
    Creates a new list of ages that are <= to the state's max_age
    :param state:
    :param ages: Children ages
    :return: List of the ages of eligible children
    """
    state_data = STATE_REFERENCE_PARAMETERS[state]
    max_age_child = state_data['eligibility']['rules']['max_age_child']
    return list(filter(lambda x: x <= max_age_child, ages))


def filter_eligible(state, earned_income=0, household_size=0, tanf_recipient=False, child_ages=[], fulltime_age=5,
                    assets=0, continuing_eligibility=False):
    """
    Returns a subset of child_ages for each child that is eligible
    :param state:
    :param earned_income:
    :param household_size:
    :param tanf_recipient:
    :param child_ages: list of the children ages
    :param fulltime_age: below this age, children attend full time. Equal or greater, they attend part time
    :return:
    """

    income = earned_income
    state_data = STATE_REFERENCE_PARAMETERS[state]

    if 'asset_test' in state_data['eligibility']['rules'] and \
            assets > state_data['eligibility']['rules']['asset_test']['asset_limits']:
        # The state has an asset test and the family exceeds the asset limit, so no children are eligible
        return []

    # Children must be below the state's max age
    child_ages = filter_max_age(state, child_ages)
    fulltime_ages, parttime_ages = separate_by_care_level(child_ages, fulltime_age)

    income_limit = lookup_eligibility_amount(state, household_size=household_size, tanf_recipient=tanf_recipient,
                                             fulltime_ages=fulltime_ages,
                                             parttime_ages=parttime_ages, continuing_eligibility=False)

    if 'child_in_care_number_1' not in state_data['copays']['by_group'] and len(state_data['copays']['by_group'].keys()) > 0:
        # TODO: really, we should be iterating over child_in_care_number_# like in calculate with calculate_with_multiple_groups
        copay_group = determine_copay_group(state_data, fulltime_ages, parttime_ages)

        reference_index, state_family_size = get_reference_index_from_copay_group(copay_group, household_size, income)
        if reference_index >= len(copay_group['copay_reference_amount'][state_family_size]):
            # OK has different family groups with different number of thresholds - there are income levels for the
            # family group with the most levels. That means that some families will be beyond the highest limit. In that
            # case, the family is not eligible.
            return []

    if income < income_limit:
        return fulltime_ages + parttime_ages
    else:
        return []


def make_parser():
    parser = argparse.ArgumentParser(description=__doc__, add_help=True)
    parser.add_argument("--ccdf_parameter_file", default=get_full_path('data/ccdf.json'))
    parser.add_argument("--ccdf_parameter_file_year", type=int, default=CCDF_PARAMETER_YEAR)

    parser.add_argument("--year", type=int)
    parser.add_argument("--state")
    parser.add_argument("--gross_income", type=float)
    parser.add_argument("--household_size", type=int)
    parser.add_argument("--young_children", type=int)
    parser.add_argument("--school_age_children", type=int)
    parser.add_argument("--monthly_childcare_cost", type=float)
    parser.add_argument("--has_tanf", default=False, action="store_true")

    return parser


def initialize(ccdf_parameter_file):
    global STATE_REFERENCE_PARAMETERS
    with open(ccdf_parameter_file) as json_file:
        STATE_REFERENCE_PARAMETERS = json.load(json_file)


def main(args=None):
    parser = argparse.ArgumentParser(description=__doc__, add_help=True)

    parser.add_argument("--ccdf_parameter_file", required=True)
    parser.add_argument("--state", required=True)
    parser.add_argument("--household_size", required=True, type=int)
    parser.add_argument("--earned_income", required=True, type=float)
    parser.add_argument("--monthly_childcare_cost", required=True, type=float)
    parser.add_argument("--child_ages", nargs='+', required=True)
    parser.add_argument("--continuing_eligibility", required=True, type=bool)
    parser.add_argument("--parttime_age", help="Age when a child starts parttime care", required=True, type=int)

    args = parser.parse_args(args)

    initialize(args.ccdf_parameter_file)

    child_ages = list(map(lambda x: int(x), args.child_ages))
    eligible_children = filter_eligible(args.state, earned_income=args.earned_income, household_size=args.household_size, child_ages=child_ages, fulltime_age=args.parttime_age, continuing_eligibility=args.continuing_eligibility)

    result = {
        "eligible_children_ages": eligible_children
    }
    if len(eligible_children) > 0:
        calculated_copay = calculate_copay(args.state, earned_income=args.earned_income, household_size=args.household_size, child_ages=eligible_children, monthly_childcare_cost=args.monthly_childcare_cost)
        result['annual_copay'] = calculated_copay

    # print(result)
    print(json.dumps(result, sort_keys=True, indent=4))



CCDF_PARAMETER_YEAR = 2019

# import numpy as np

def initialize_calculate_store(args):
    try:
        if 'state_id' in args:
            args['state'] = STATE_ID_TO_ABBREVIATION[args['state_id']]

        args['ccdf_parameter_file'] = get_full_path('ccdf.json')
        args['ccdf_parameter_file_year'] = CCDF_PARAMETER_YEAR

        global STATE_REFERENCE_PARAMETERS
        if STATE_REFERENCE_PARAMETERS is None:
            ccdf_parameter_file = args['ccdf_parameter_file']
            logger.info(f"loading file: {ccdf_parameter_file}")
            with open(ccdf_parameter_file) as json_file:
                STATE_REFERENCE_PARAMETERS = json.load(json_file)

        # state_data = STATE_REFERENCE_PARAMETERS[args['state']]
        # copay = calculate_copay(state_data, args)

        # TODO - c/p from main
        if 'child_ages' in args:
            child_ages = list(map(lambda x: int(x), args['child_ages']))
        else:
            child_ages = [2, 7]

        eligible_children = filter_eligible(args['state'], earned_income=args['earned_income'], household_size=args['household_size'], child_ages=child_ages, fulltime_age=args['parttime_age'], continuing_eligibility=args['continuing_eligibility'])

        annual_cost = args['monthly_childcare_cost'] * 12
        if len(eligible_children) > 0:
            calculated_copay = calculate_copay(args['state'], earned_income=args['earned_income'], household_size=args['household_size'], child_ages=eligible_children, monthly_childcare_cost=args['monthly_childcare_cost'])
            calculated_copay = min(annual_cost, calculated_copay)
        else:
            calculated_copay = annual_cost

        args['net_annual_transfer'] = np.array([annual_cost - calculated_copay])

        # logger.info(f"ccdf args: {args}")
    except Exception as e:
        logger.exception(f"exception: {e}", exc_info=True)
        raise e


if __name__ == '__main__':
    main()


# MN - ESPBasic_TC00376-input.xml

# All fortran:
# Stop time       3.282578

# Stub:
# Stop time       4.455853

# Full:
# Stop time       4.431051

