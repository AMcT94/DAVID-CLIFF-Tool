from enum import Enum

class FilingStatus(Enum):
    SINGLE = "SINGLE"
    MARRIED_FILING_JOINTLY = "MFJ"
    HEAD_OF_HOUSEHOLD = "HH"
    WIDOW_AND_DEPENDENT = "WD"

class Applicant:

    def __init__(self,
                 filing_status=FilingStatus.SINGLE,
                 dependent=[],
                 earned_income=None,
                 spouse_earned_income=None,
                 federal_adjusted_gross_income=None,
                 federal_cdctc=None,
                 federal_cdctc_before_tax_liability=None,
                 federal_tax_liability=None,
                 state_adjusted_gross_income=None,
                 state_tax_liability=None,
                 net_income=None,
                 spouse_net_income=None,
                 certified_early_child_expense_amount=None,
                 household_size=None):
        if isinstance(filing_status, FilingStatus):
            self.filing_status = filing_status
        else:
            raise TypeError("filing_status must be of type FilingStatus")
        self.dependent = dependent
        self.earned_income = earned_income
        self.spouse_earned_income = spouse_earned_income
        self.federal_adjusted_gross_income = federal_adjusted_gross_income
        self.federal_cdctc = federal_cdctc
        self.federal_cdctc_before_tax_liability = federal_cdctc_before_tax_liability
        self.federal_tax_liability = federal_tax_liability
        self.state_adjusted_gross_income = state_adjusted_gross_income
        self.state_tax_liability = state_tax_liability
        self.net_income = net_income
        self.spouse_net_income = spouse_net_income
        # TODO: FIND A BETTER WAY TO ASSING HOUSEHOLD NET INCOME
        # this property is used in Iowa's second calc eligibility
        self.household_net_income = net_income if spouse_net_income is None or net_income is None else net_income + spouse_net_income
        self.certified_early_child_expense_amount = certified_early_child_expense_amount
        self.household_size = household_size
