import datetime
import math
import numpy as np


STATE_ID_TO_ABBREVIATION = {
    1: 'AL',
    2: 'AK',
    3: 'AZ',
    4: 'AR',
    5: 'CA',
    6: 'CO',
    7: 'CT',
    8: 'DE',
    9: 'DC',
    10: 'FL',
    11: 'GA',
    12: 'HI',
    13: 'ID',
    14: 'IL',
    15: 'IN',
    16: 'IA',
    17: 'KS',
    18: 'KY',
    19: 'LA',
    20: 'ME',
    21: 'MD',
    22: 'MA',
    23: 'MI',
    24: 'MN',
    25: 'MS',
    26: 'MO',
    27: 'MT',
    28: 'NE',
    29: 'NV',
    30: 'NH',
    31: 'NJ',
    32: 'NM',
    33: 'NY',
    34: 'NC',
    35: 'ND',
    36: 'OH',
    37: 'OK',
    38: 'OR',
    39: 'PA',
    40: 'RI',
    41: 'SC',
    42: 'SD',
    43: 'TN',
    44: 'TX',
    45: 'UT',
    46: 'VT',
    47: 'VA',
    48: 'WA',
    49: 'WV',
    50: 'WI',
    51: 'WY'
}


POVERTY = {
    2007: {
        "other": {"base": 10210, "extra": 3480},
    },

    2017: {
        "other": {"base": 12060, "extra": 4180},
        "AK":    {"base": 15060, "extra": 5230},
        "HI":    {"base": 13860, "extra": 4810}
    },
    2018: {
        "other": {"base": 12140, "extra": 4320},
        "AK":    {"base": 15180, "extra": 5400},
        "HI":    {"base": 13960, "extra": 4810},
    },
    2019: {
        "other": {"base": 12490, "extra": 4420},
        "AK":    {"base": 15600, "extra": 5530},
        "HI":    {"base": 14380, "extra": 5080},
    },
    2020: {
        "other": {"base": 12760, "extra": 4480},
        "AK": {"base": 15950, "extra": 5600},
        "HI": {"base": 14680, "extra": 5150},
    }
}

def get_poverty_level(year, state, household_size):
    """
    Gets the poverty level for the given state, year, and household size

    :param year: int
    :param state: str
    :param household_size: int
    :return: int
    """
    poverty_for_year = POVERTY[year]
    if state in poverty_for_year:
        poverty_for_year = poverty_for_year[state]
    else:
        poverty_for_year = poverty_for_year["other"]
    return poverty_for_year['base'] + (poverty_for_year['extra'] * (household_size - 1))

"""
Convert Julian Day to date.

@source: https://gist.github.com/jiffyclub/1294443   
Algorithm from 'Practical Astronomy with your Calculator or Spreadsheet', 
4th ed., Duffet-Smith and Zwart, 2011.
        
Examples
--------
    Convert Julian Day 2446113.75 to date(year, month, day).
    >>> julian_date_to_date(2446113.75)
    datetime.date(1985, 2, 17)
"""
def julian_date_to_date(jd):
    """
    Convert Julian Day to date.

    :param jd: float
    :return date: datetime
    """
    jd = jd + 0.5
    F, I = math.modf(jd)
    A = math.trunc((I - 1867216.25)/36524.25)
    if I > 2299160:
        B = I + 1 + A - math.trunc(A / 4.)
    else:
        B = I
    C = B + 1524
    D = math.trunc((C - 122.1) / 365.25)
    E = math.trunc(365.25 * D)
    G = math.trunc((C - E) / 30.6001)
    day = C - E + F - math.trunc(30.6001 * G)
    if G < 13.5:
        month = G - 1
    else:
        month = G - 13
    if month > 2.5:
        year = D - 4716
    else:
        year = D - 4715
    return datetime.date(year, month, math.floor(day))

def validate_data(data, cast=None, condition=None, error_message=None):
    """
    Validates data to the correct data type

    :param data: Any
    :param cast: data-type
    :param condition:
    :param error_message: str
    :return: Any
    """
    try:
        if cast is bool:
            data = str(data).strip().lower() not in ("0", "na") # converts str "0" or "na" to False
        else:
            data = (cast or str)(data)
        assert condition is None or condition(data)
        return data
    except TypeError as e:
        print(error_message or f"{e}: {data} is an invalid input")

def remove_elements_by_value(list_of_elements, value):
    """
    Removes an element from a list if value equals element

    :param list_of_elements: list
    :param value: Any
    :return:
    """
    arr = np.array(list_of_elements)
    return np.delete(arr, np.argwhere(arr == value))
