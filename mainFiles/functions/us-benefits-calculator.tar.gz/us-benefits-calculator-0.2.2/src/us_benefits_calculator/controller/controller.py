from us_benefits_calculator.benefit_names import BenefitNames
from us_benefits_calculator.utils import validate_data
from us_benefits_calculator.programs.wic.wic_calculator import Wic

# ---Global Variables---
wic = None


class Controller:
    """
    This controller receives parameters with family data, manages the calculation of benefits,
    and provides access to the results of each benefit program calculation.
    """

    ##################
    # Public functions
    ##################
    @staticmethod
    def calculate_household_benefits(family_data, options):
        """
        Calculate the benefits for all enabled programs. This function receives parameters with family data,
        manages the calculation of benefits, and provides access to the results of each benefit program calculation.

        :param family_data: dict
        :param options: dict
        :return: a dict with the results of all enabled program calculations
        """
        all_benefit_results = {
            BenefitNames.WIC.value: {'monthly_benefit': 0},
            BenefitNames.ACA.value: {'monthly_benefit': 0},
            BenefitNames.FED_CDCTC.value: {'monthly_benefit': 0}
        }
        # Calculate Wic
        if Controller._is_program_enabled(BenefitNames.WIC.value, options):
            form = Controller._calculate_monthly_benefit_wic(family_data)
            all_benefit_results[BenefitNames.WIC.value]['monthly_benefit'] = form['monthly_wic_benefit']
            if options['debug']:
                all_benefit_results[BenefitNames.WIC.value]['detailed_report'] = form
        return all_benefit_results

    ###################
    # Private functions
    ###################
    @staticmethod
    def _is_program_enabled(program_name, options):
        """
        Checks if program name exist and is set to True

        :param program_name: str
        :param options: dict
        :return: bool
        """
        return True if program_name in options and options[program_name] else False

    ###############################
    # Private benefits calculations
    ###############################
    @staticmethod
    def _calculate_monthly_benefit_wic(family_data):
        """
        Calculate monthly wic benefit and add the results to the benefits dict

        :param family_data: dict
        :return: (float, Form)
        """
        global wic
        if wic is None:
            wic = Wic()
        return wic.calculate_monthly_benefit(
            validate_data(family_data['annual_income'], float),
            family_data['dependents_age'],
            validate_data(family_data['children_accept_medicaid'], bool),
            validate_data(family_data['adult_accept_medicaid'], bool),
            validate_data(family_data['household_accept_tanf'], bool),
            validate_data(family_data['household_accept_snap'], bool),
            validate_data(family_data['household_size'], int),
            validate_data(family_data['state_abbreviation'], str),
            validate_data(family_data['household_has_mother'], bool)
        )
