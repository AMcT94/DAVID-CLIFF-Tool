from datetime import datetime
from dateutil.relativedelta import relativedelta
from us_benefits_calculator.programs.wic.wic_calculator import Wic
from us_benefits_calculator.utils import remove_elements_by_value, validate_data
import us_benefits_calculator.programs.tanf.tanf_calculator as tanf_calc

# ---Global Variable---
wic = None
tanf = None


class CliffAdapter:
    """Interface for Cliff Planner Tool"""

    @staticmethod
    def calc_tanf(income_ind, income_other_family, income_child_support, income_gift, income_investment, age_person2,
                  age_person3, age_person4, age_person5, age_person6, age_person7, state_abbrev, num_adults, value_ssi,
                  asset_cash, current_year, assistance_history=None):
        """
        Takes in args from the Cliff and translates the args to the necessary type for TANF calculation

        NOTE: TANF calcs need to know age at beginning of month and python function uses exact birthdate to
              determine that. We assume the ages provided here are the ages at beginning of month and generate a
              fake birthdate that will equate to the age.

        :param income_ind: str
        :param income_other_family: str
        :param income_child_support: str
        :param income_gift: str
        :param income_investment: str
        :param age_person2: str
        :param age_person3: str
        :param age_person4: str
        :param age_person5: str
        :param age_person6: str
        :param age_person7: str
        :param state_abbrev: str
        :param num_adults: str
        :param value_ssi: str
        :param asset_cash: str
        :param current_year: str
        :param assistance_history: dict{'history': {}}
        :return: dict: {}
        """
        # instantiate tanf
        global tanf
        if tanf is None:
            tanf_calc.initialize()
            tanf = tanf_calc.STATE_REFERENCE_PARAMETERS
        # create family
        family = {"adults": [], "children": []}
        primary = {"income": {}, "assets": {}}
        # primary adult
        primary["income"]["earned_income"] = validate_data(income_ind, float)
        primary["income"]["unearned_income"] = validate_data(income_child_support, float) + validate_data(income_gift, float) + validate_data(income_investment, float)
        primary["income"]["ssi"] = validate_data(value_ssi, float)
        primary["assets"]["cash"] = validate_data(asset_cash, float)
        family["adults"].append(primary)  # add primary to the family
        # add other adults/children to the family
        current_year = validate_data(current_year, int)
        ages = remove_elements_by_value([age_person2, age_person3, age_person4, age_person5, age_person6, age_person7],'NA')
        for age in ages:
            age = validate_data(age, int, lambda x: x > -1, f'{age} must be an Integer and positive')
            if age < 19:  # TODO: have tanf determine child
                birthdate = datetime.today() - relativedelta(years=age)
                family["children"].append({"birthdate": birthdate.isoformat(), "income": []})
            else:
                # all other adults in household
                adult = {"income": {}, "assets": {}}
                # distribute other income for the rest of the adults in household
                other_income_distributed = validate_data(income_other_family, int) / (validate_data(num_adults, int) - 1)
                adult["income"]["earned_income"] = other_income_distributed
                adult["income"]["unearned_income"] = 0
                adult["income"]["ssi"] = 0
                adult["assets"]["cash"] = 0
                family["adults"].append(adult)
        # calculate
        return tanf_calc.calculate_cash_benefits(state_abbrev,
                                                 tanf_calc.REAL_DOLLAR_YEAR,
                                                 family,
                                                 current_year,
                                                 assistance_history)

    @staticmethod
    def calc_wic(income, income_gift, age_person3, age_person4, age_person5, age_person6, age_person7,
                 household_size, state_abbrev, snap_amount, tanf_amount, adult_medicaid_value, child_medicaid_value):
        """
        Takes in args from the Cliff and translates the args to the necessary type for WIC calculation

        :param income: str
        :param income_gift: str
        :param age_person3: str
        :param age_person4: str
        :param age_person5: str
        :param age_person6: str
        :param age_person7: str
        :param household_size: str
        :param state_abbrev: str
        :param snap_amount: str
        :param tanf_amount: str
        :param adult_medicaid_value: str
        :param child_medicaid_value: str
        :return: dict: {}
        """
        # instantiate wic
        global wic
        if wic is None:
            wic = Wic()
        # translate/validate args to correct type
        countable_income = validate_data(income, float) + validate_data(income_gift, float)
        ages = remove_elements_by_value([age_person3, age_person4, age_person5, age_person6, age_person7], 'NA')
        valid_ages = []
        for age in ages:
            age = validate_data(age, int, lambda x: x > -1, f'{age} must be an Integer and positive')
            valid_ages.append(age)
        # calculate
        return wic.calculate_monthly_benefit(countable_income,
                                             valid_ages,
                                             validate_data(child_medicaid_value, bool),
                                             validate_data(adult_medicaid_value, bool),
                                             validate_data(tanf_amount, bool),
                                             validate_data(snap_amount, bool),
                                             validate_data(household_size, int),
                                             validate_data(state_abbrev, str))
